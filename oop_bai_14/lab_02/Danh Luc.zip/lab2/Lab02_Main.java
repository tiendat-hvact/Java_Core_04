package javacore.basic.lesson14.lab2;

import com.google.gson.Gson;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javacore.basic.lesson14.lab2.model.JsonResult;
import javacore.basic.lesson14.lab2.model.List;

public class Lab02_Main {
    
    private static final String currentDir = System.getProperty("user.dir");
    private static final String separator = File.separator;
    private static final String Path_Json_File = currentDir + separator + "data" + separator + "weather_16days.json";
    
    static JsonResult ReadFileJson() {
        FileReader fr = null;
        JsonResult weather = new JsonResult();
        try {
            fr = new FileReader(Path_Json_File);
            Gson gson = new Gson();
            weather = gson.fromJson(fr, JsonResult.class);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Lab02_Main.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fr.close();
            } catch (IOException ex) {
                Logger.getLogger(Lab02_Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return weather;
    }
    
    static void Show(JsonResult jsonResult) {
        for (List item : jsonResult.getList()) {
            item.showList();
        }
    }
    
    static void ShowMaxTemp(JsonResult jsonResult) {
        System.out.println("===================================");
        System.out.println("ngay co nhiet do cao nhat");
        jsonResult.getList().sort(new TempComparator().thenComparing(new HumidityComparator()).thenComparing(new DateComparator()));
        jsonResult.getList().get(0).showList();
    }
    
    static void ShowMaxWindSpeed(JsonResult jsonResult) {
        System.out.println("=======================================");
        System.out.println("Ngay co toc do gio cao nhat");
        jsonResult.getList().sort(new WindSpeedComparator().thenComparing(new DateComparator()));
        jsonResult.getList().get(0).showList();
    }
    
    static void ShowRainDays(JsonResult jsonResult) {
        System.out.println("======================================");
        System.out.println("nhung ngay mua:");
        jsonResult.getList().sort(new DateComparator());
        for (List item : jsonResult.getList()) {
            if (item.getWeather().get(0).getMain().equals("Rain")) {
                item.showList();
            }
        }
    }
    
    public static void main(String[] args) {
        JsonResult weather = ReadFileJson();
        Show(weather);
        ShowMaxTemp(weather);
        ShowMaxWindSpeed(weather);
        ShowRainDays(weather);
    }
}
