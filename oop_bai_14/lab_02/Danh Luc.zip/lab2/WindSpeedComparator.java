/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.lesson14.lab2;

import java.util.Comparator;
import javacore.basic.lesson14.lab2.model.List;

/**
 *
 * @author admin
 */
public class WindSpeedComparator implements Comparator<List> {

    @Override
    public int compare(List l1, List l2) {
        if (l1.getWind().getSpeed() > l2.getWind().getSpeed()) {
            return -1;
        } else if (l1.getWind().getSpeed() == l2.getWind().getSpeed()) {
            return 0;
        }
        return 1;
    }

}
