/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson14.lab01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Lab01 {

    static String path = "C:\\JavaCore\\Bai14\\Lab01";
    static String pathInput = "C:\\JavaCore\\Bai14\\Lab01\\diemthi_input.csv";
    static String PathOutput = "C:\\JavaCore\\Bai14\\Lab01\\diemthi_output.csv";

    public static void main(String[] args) throws IOException {

        ArrayList<ThiSinh> list = new ArrayList<>();
        File dir = new File(path);
        dir.mkdirs();
        File file = new File(pathInput);
        file.createNewFile();

        BufferedReader bf = null;
        try {
            bf = new BufferedReader(new FileReader(pathInput));
            bf.readLine();
            String line = null;
            while ((line = bf.readLine()) != null) {
                String a[] = line.split(",");
                int SBD = Integer.parseInt(a[0]);
                double tongDiem = Double.parseDouble(a[4]);
                ThiSinh ts = new ThiSinh(SBD, a[1], a[2], a[3], tongDiem);
                list.add(ts);
            }
            bf.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Lab01.class.getName()).log(Level.SEVERE, null, ex);
        }
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        sc.nextLine();
        for (int i = 0; i < N; i++) {
            String input = sc.nextLine();
            if (input.startsWith("1")) {
                list.sort(new SapXepHoTen());
                String a[] = input.split(" ");
                for (int j = 0; j < list.size(); j++) {
                    ThiSinh ts = list.get(j);
                    if (ts.getGioiTinh().equals(a[1])) {
                        System.out.println(ts.toString());
                    }
                }
            } else if (input.startsWith("2")) {
                list.sort(new SapXepHoTen());
                String a[] = input.split(" ");
                for (int j = 0; j < list.size(); j++) {
                    ThiSinh ts = list.get(j);
                    if (ts.getTinh().equals(a[1])) {
                        System.out.println(ts.toString());
                    }
                }

            } else if (input.startsWith("3")) {
                list.sort(new SapXepHoTen());
                String a[] = input.split(" ");
                int sbd = Integer.parseInt(a[1]);
                int y = Integer.parseInt(a[2]);
                for (int j = 0; j < list.size(); j++) {
                    ThiSinh ts = list.get(j);
                    if (ts.getSBD() == sbd) {
                        if (y == 1) {
                            ts.setTinh(a[3]);
                        } else {
                            double td = Double.parseDouble(a[3]);
                            ts.setTongDiem(td);
                        }
                    }

                }
            } else if (input.startsWith("4")) {
                list.sort(new SapXepHoTen());
                String a[] = input.split(" ");
                int sbd = Integer.parseInt(a[1]);
                boolean check = false;
                for (int j = 0; j < list.size(); j++) {
                    ThiSinh ts = list.get(j);
                    if (ts.getSBD() == sbd) {
                        list.remove(j);
                        check = true;
                        System.out.println("1");
                        break;
                    }
                }
                if (check == false) {
                    System.out.println("0");
                }
            } else if (input.startsWith("5")) {
                list.sort(new SapXepHoTen());
                String a[] = input.split(" ");
                int y = Integer.parseInt(a[1]);
                list.sort(new SapXepDiem());
                for (int j = 0; j < y; j++) {
                    System.out.println(list.get(j).toString());
                }
            } else if (input.startsWith("6")) {
                list.sort(new SapXepDiem().thenComparing(new SapXepHoTen().thenComparing(new SapXepTinh())));
                File file1 = new File(PathOutput);
                if (file1.isFile() == false) {
                    file1.createNewFile();
                }
                BufferedWriter bff = new BufferedWriter(new FileWriter(PathOutput));
                for (int j = 0; j < list.size(); j++) {
                    ThiSinh ts = list.get(j);
                    String line = ts.getSBD() + "," + ts.getHoTen() + "," + ts.getGioiTinh() + "," + ts.getTinh() + "," + ts.getTongDiem();
                    bff.write(line);
                    bff.write("\n");

                }
                bff.close();
            }
        }
    }
}
