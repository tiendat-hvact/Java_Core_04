/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacor.basic.les14.lab01;

import java.util.Comparator;

/**
 *
 * @author LaptopDT
 */
class SapXepHoTen implements Comparator<ThiSinh> {

    @Override
    public int compare(ThiSinh o1, ThiSinh o2) {
        int i = o1.getHoTen().length() - 1;
        for (i = o1.getHoTen().length() - 1; i >= 0; i--) {
            int a = (int) o1.getHoTen().charAt(i);
            if (a >= 65 && a <= 90) {
                break;
            }
        }
        int j = o2.getHoTen().length() - 1;
        for (j = o2.getHoTen().length() - 1; j >= 0; j--) {
            int a = (int) o2.getHoTen().charAt(j);
            if (a >= 65 && a <= 90) {
                break;
            }
        }
        String ten1 = o1.getHoTen().substring(i);
        String ten2 = o2.getHoTen().substring(j);

        return ten1.compareTo(ten2);
    }
}
