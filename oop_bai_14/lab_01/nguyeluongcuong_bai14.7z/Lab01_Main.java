/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai14Lab01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class Lab01_Main {
    
    static String pathCreate = "C:\\JavaCore\\Bai14\\Lab01";
    static String pathInput = "C:\\JavaCore\\Bai14\\Lab01\\diemthi_input.csv";
    static String pathOutput = "C:\\JavaCore\\Bai14\\Lab01\\diemthi_output.csv";
    
    public static void main(String[] args) throws IOException {
        ArrayList<ThiSinh> list = new ArrayList<>();
        File file = new File(pathCreate);
        file.mkdirs();
        file = new File(pathInput);
        file.createNewFile();
        
        try {
            BufferedReader bf = new BufferedReader(new FileReader(pathInput));
            String line;
            bf.readLine();
            while ((line = bf.readLine()) != null) {                
                String a[] = line.split(",");
                int SBD = Integer.parseInt(a[0]);
                double diem = Double.parseDouble(a[4]);
                list.add(new ThiSinh(SBD,a[1],a[2],a[3],diem));
            }       
            bf.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Lab01_Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Scanner scan = new Scanner(System.in);
        int N = scan.nextInt();
        scan.nextLine();
        for(int i = 0;i<N;i++){
            String input = scan.nextLine();
            if(input.startsWith("1")){
                list.sort(new SapXepHoTen());
                String a[] = input.split(" ");
                
                for(int k = 0;k<list.size();k++){
                    ThiSinh ts = list.get(k);
                    if(ts.getGioiTinh().equals(a[1])){
                        System.out.println(ts.toString());
                    }
                }
                
            }else if(input.startsWith("2")){
                list.sort(new SapXepHoTen());
                String a[] = input.split(" ");
                
                for(int k = 0;k<list.size();k++){
                    ThiSinh ts = list.get(k);
                    if(ts.getTinh().equals(a[1])){
                        System.out.println(ts.toString());
                    }
                }
                
            }else if(input.startsWith("3")){
                list.sort(new SapXepHoTen());
                String a[] = input.split(" ");
                int sbd = Integer.parseInt(a[1]);
                int y = Integer.parseInt(a[2]);
                for(int k = 0;k<list.size();k++){
                    ThiSinh ts = list.get(k);
                    if(ts.getSBD() == sbd){
                        if(y == 1){
                            ts.setTinh(a[3]);
                        }else{
                            double td = Double.parseDouble(a[3]);
                            ts.setTongDiem(td);
                        }
                    }
                }
                
            }else if(input.startsWith("4")){
                list.sort(new SapXepHoTen());
                String a[] = input.split(" ");
                int sbd = Integer.parseInt(a[1]);
                
                boolean check = false;
                for(int k = 0;k<list.size();k++){
                    ThiSinh ts = list.get(k);
                    if(ts.getSBD() == sbd){
                        list.remove(k);
                        check = true;
                        System.out.println("1");
                        break;
                    }
                }
                if(check == false){
                    System.out.println("0");
                }
            }else if(input.startsWith("5")){
                list.sort(new SapXepHoTen());
                String a[] = input.split(" ");
                int y = Integer.parseInt(a[1]);
                list.sort(new SapXepDiem());
                for(int k = 0;k<y;k++){
                    System.out.println(list.get(k).toString());
                }
            }else if(input.startsWith("6")){
                list.sort(new SapXepDiem().thenComparing(new SapXepHoTen().thenComparing(new SapXepTinh())));
                File file1 = new File(pathOutput);
                if(file1.isFile() == false){
                    file1.createNewFile();
                }
                BufferedWriter bf = new BufferedWriter(new FileWriter(pathOutput));
                for(int k = 0;k <list.size();k++){
                    ThiSinh ts = list.get(k);
                    String line = ts.getSBD() + "," + ts.getHoTen() + "," + ts.getGioiTinh()+ "," + ts.getTinh()+ "," + ts.getTongDiem();
                    bf.write(line);
                    bf.write("\n");
                }
                bf.close();
            }
        }
    }
}


class SapXepDiem implements Comparator<ThiSinh>{

    @Override
    public int compare(ThiSinh o1, ThiSinh o2) {
        if(o1.getTongDiem() > o2.getTongDiem()){
            return -1;
        }else if(o1.getTongDiem() == o2.getTongDiem()){
            return 0;
        }else{
            return 1;
        }
    }    
}

class SapXepHoTen implements Comparator<ThiSinh>{

    @Override
    public int compare(ThiSinh o1, ThiSinh o2) {
        int i = o1.getHoTen().length() - 1;
        for(i = o1.getHoTen().length() - 1;i>=0;i--){
            int a = (int) o1.getHoTen().charAt(i);
            if(a>=65&&a<=90){
                break;
            }
        }
        int j = o2.getHoTen().length() - 1;
        for(j = o2.getHoTen().length() - 1;j>=0;j--){
            int a = (int) o2.getHoTen().charAt(j);
            if(a>=65&&a<=90){
                break;
            }
        }
        String ten1 = o1.getHoTen().substring(i);
        String ten2 = o2.getHoTen().substring(j);
        
        return ten1.compareTo(ten2);
    }    
}

class SapXepTinh implements Comparator<ThiSinh>{

    @Override
    public int compare(ThiSinh o1, ThiSinh o2) {
        return o1.getTinh().compareTo(o2.getTinh());
    }    
}
    

