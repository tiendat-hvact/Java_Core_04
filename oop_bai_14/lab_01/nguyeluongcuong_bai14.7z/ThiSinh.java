/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai14Lab01;

/**
 *
 * @author ADMIN
 */
public class ThiSinh {
    private int SBD;
    private String hoTen;
    private String gioiTinh;
    private String tinh;
    private double tongDiem;

    public ThiSinh(int SBD, String hoTen, String gioiTinh, String tinh, double tongDiem) {
        this.SBD = SBD;
        this.hoTen = hoTen;
        this.gioiTinh = gioiTinh;
        this.tinh = tinh;
        this.tongDiem = tongDiem;
    }

    

    public double getTongDiem() {
        return tongDiem;
    }

    public void setTongDiem(double tongDiem) {
        this.tongDiem = tongDiem;
    }

    public int getSBD() {
        return SBD;
    }

    public void setSBD(int SBD) {
        this.SBD = SBD;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getTinh() {
        return tinh;
    }

    public void setTinh(String tinh) {
        this.tinh = tinh;
    }

    @Override
    public String toString() {
        return "ThiSinh{" + "SBD=" + SBD + ", hoTen=" + hoTen + ", gioiTinh=" + gioiTinh + ", tinh=" + tinh + ", tongDiem=" + tongDiem + '}';
    } 
}
