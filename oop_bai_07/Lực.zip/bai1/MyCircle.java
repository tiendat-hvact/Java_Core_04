/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson07.bai1;

/**
 *
 * @author Luc
 */
public class MyCircle {
    // khởi tạo tâm có kiểu dữ kiệu MyPoint 
    private MyPoint tam;
    private double bankinh;

    //khoi tạo thông tin mặc định tâm(0,0) bán kính = 0; trong hàm không tham số.
    public MyCircle() {
        this.tam = new MyPoint(0, 0);
        this.bankinh = 0;
    }
 // khởi tạo tâm có tọa độ MyPoint bk r;
    public MyCircle(double x, double y, double bankinh) {
        this.tam = new MyPoint();
        this.tam.setX(x);
        this.tam.setY(y);
        this.bankinh = bankinh;
    }

    public MyCircle(MyPoint tam, double bankinh) {
        this.tam = tam;
        this.bankinh = bankinh;
    }

    public MyPoint getTam() {
        return tam;
    }

    public void setTam(MyPoint tam) {
        this.tam = tam;
    }

    public double Bankinh() {
        return bankinh;
    }

    public void Bankinh(double bankinh) {
        this.bankinh = bankinh;
    }
    
    //tinh chu vi
    public double getCircumference(){
        return 2*Math.PI*this.bankinh;
    }
    public double getArea(){
        return this.bankinh*this.bankinh*Math.PI;
    }

    public String toString() {
        String s1 = String.format("Circle info:(% .2f, %.2f), radius = %.2f, circumference = %.3f, area = %.3f\n",
               getTam().getX(),getTam().getY(),Bankinh(),getCircumference(),getArea());
        return s1;
    }   

}
