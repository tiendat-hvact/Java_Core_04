/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson07.bai1;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class Solution {
public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        //nhap số lượng test case:
        int T = sc.nextInt();
        int k;
        double x1, y1, x, y;
        //khai bao các chỉ số.
        int t, ii, n, p, m, q, i, j;
        for (t = 0; t < T; t++) {
            n = sc.nextInt();
            // khoi tao mang chua điểm mang kiểu dữ liệu mypoint: trong điểm đó có chứa x,y
            MyPoint[] points = new MyPoint[n];
            for (ii = 0; ii < n; ii++) {
                points[ii] = new MyPoint();
                //khơi tạo điểm để nhập X,Y:
                points[ii].setX(sc.nextDouble());
                points[ii].setY(sc.nextDouble());
            }
            k = sc.nextInt();
            x1 = sc.nextDouble();
            y1 = sc.nextDouble();
            p = sc.nextInt();
            m = sc.nextInt();
            //khai báo mảng chứa m đường tròn:
            MyCircle[] cricles = new MyCircle[m];
            for (ii = 0; ii < m; ii++) {
                //muon truy cap đến tâm thì khơi tạo kiểu dữ liệu là class tên class đó
                cricles[ii] = new MyCircle();
                //
                x = sc.nextDouble();
                y = sc.nextDouble();
                cricles[ii].setTam(new MyPoint(x, y));
            }
            //dãy m cho biết bán kính đường tròn thứ ii
            for (ii = 0; ii < m; ii++) {
                cricles[ii].Bankinh(sc.nextDouble());
            }
            q = sc.nextInt();
            i = sc.nextInt();
            j = sc.nextInt();

            System.out.printf("Case #%d:\n", t + 1);
            System.out.printf("distance = %.3f\n", points[k].getDistance(x1, y1));
            System.out.println(points[p].toString());
            System.out.printf(cricles[q].toString());

            // tim vi tri tuong do doi  hai duong tròn
            // khởi tạo hai đường tròn có tâm đã khởi tạo kiểu MyPoint.
            MyPoint tam1 = new MyPoint();
            // lấy hàm có sẵn ở Mycricles do khởi tạo
            // bên trên lên chỉ cần gọi tên khởi tạo bên trên rồi chấm tam là đc
            tam1 = cricles[i].getTam();

            MyPoint tam2 = new MyPoint();
            tam2 = cricles[j].getTam();
            //tính khoảng cách từ taam1 đến taam2 dùng hàm có sẵn.
            double kc = tam1.getDistance(tam2.getX(), tam2.getY());
            // lấy độ dài bán kính từ class Mycricles chấm là đc.
            double rj = cricles[j].Bankinh();
            double ri = cricles[i].Bankinh();
            //mang đi so sánh lần lượt.
            double r = Math.abs(rj - ri);
            double r1 = ri + rj;
            if ((kc == 0 && ri == rj)|| kc >= r && kc <= r1) {
                System.out.printf("Circle %d intersects with Circle %d\n",i,j);
            }
            else if (kc < (rj - ri) && rj > ri) {
                System.out.printf("Circle %d is inside Circle %d\n",i,j);
            } else {
                System.out.printf("Circle %d does not intersect Circle %d\n",i,j);
            }
        }
    }
}
