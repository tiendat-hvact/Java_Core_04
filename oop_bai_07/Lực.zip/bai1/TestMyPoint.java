/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson07.bai1;

/**
 *
 * @author Luc
 */
public class TestMyPoint {

   
    public static void main(String[] args) {
        // TODO code application logic here
        MyPoint p1 = new MyPoint(15, 20);
        MyPoint p2 = new MyPoint();
        MyPoint p3 = new MyPoint();
        
        //sử dụng set gán giá trị cho x,y;
        p2.setX(2);
        p2.setY(3);
        p3.SetXY(5, 6);
        //in ra man hình tính khoảng cách từ các điểm khơi tạo đến điểm cố định 10,10
        // do lop MyPoin có tính khoảng cách rồi lên chỉ chấm nó ra tương tự toString hàm hiển thị.
        System.out.println(p1.getDistance(10, 10));
        System.out.println(p2.getDistance(10, 10));
        System.out.println(p3.getDistance(10, 10));

        System.out.println(p1.toString());
        System.out.println(p2.toString());
        System.out.println(p3.toString());
    }

}
