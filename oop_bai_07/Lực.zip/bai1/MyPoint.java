/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson07.bai1;

/**
 *
 * @author Luc
 */
public class MyPoint {

    private double x;
    private double y;

    public MyPoint() {
        x = 0;
        y = 0;
    }

    public MyPoint(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
    // de bai yeu câu ham xet xy;
    public void SetXY(double x, double y) {
        this.x = x; 
        this.y = y;
    }

    public double getDistance(double x1, double y1) {
        double kc;
        kc = Math.sqrt((this.x - x1) * (this.x - x1) + (this.y - y1) * (this.y - y1));
        return kc;
    }
    
    public String toString() {
        return "(" + getX() + "," + getY() + ")";
    }
}
