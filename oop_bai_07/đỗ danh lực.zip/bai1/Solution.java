/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson07.bai1;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class Solution {
public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T;
        int n, t, ii, k, p, m, q, i, j;
        double x1, y1, x, y;
        T = sc.nextInt();
        for (t = 1; t <= T; t++) {
            n = sc.nextInt();
            MyPoint[] points = new MyPoint[n];
            for (ii = 0; ii < n; ii++) {
                points[ii] = new MyPoint();
                points[ii].setX(sc.nextDouble());
                points[ii].setY(sc.nextDouble());
            }
            k = sc.nextInt();
            x1 = sc.nextDouble();
            y1 = sc.nextDouble();
            p = sc.nextInt();
            m = sc.nextInt();
            MyCircle[] circles = new MyCircle[m];
            for (ii = 0; ii < m; ii++) {
                circles[ii] = new MyCircle();
                x = sc.nextDouble();
                y = sc.nextDouble();
                circles[ii].setTam(new MyPoint(x, y));
            }
            for (ii = 0; ii < m; ii++) {
                circles[ii].setR(sc.nextDouble());
            }
            q = sc.nextInt();
            i = sc.nextInt();
            j = sc.nextInt();
            System.out.printf("Case #%d:\n", t);
            System.out.printf("distance = %.3f\n", points[k].getDistance(x1, y1));
            System.out.println(points[p].toString());
            System.out.println(circles[q].toString());
            double s = circles[i].getTam().getDistance(circles[j].getTam().getX(), circles[j].getTam().getY());
            double a = circles[i].getR() + circles[j].getR();
            double b = Math.abs(circles[i].getR() - circles[j].getR());
            if (s >= b && s <= a) {
                System.out.printf("Circle %d intersects with Circle %d\n", i, j);
            } else if (s < b) {
                System.out.printf("Circle %d is inside Circle %d\n", i, j);
            } else {
                System.out.printf("Circle %d does not intersect Circle %d\n", i, j);
            }
        }
    }
}
