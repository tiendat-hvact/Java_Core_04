/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public abstract class Solution extends MyCircle {

    public abstract void cuong();

    public static void main(String[] args) {

        MyPoint[] arr;
        Scanner scan = new Scanner(System.in);
        int T = scan.nextInt();
        for (int index = 1; index <= T; index++) {
            int n = scan.nextInt();
            arr = new MyPoint[n];
            for (int t = 0; t < n; t++) {
                arr[t] = new MyPoint();
                arr[t].setX(scan.nextDouble());
                arr[t].setY(scan.nextDouble());
            }
            int k = scan.nextInt();
            double x1 = scan.nextDouble();
            double y1 = scan.nextDouble();
            int p = scan.nextInt();
            int m = scan.nextInt();
            MyCircle[] arrCircle = new MyCircle[m];
            for (int j = 0; j < m; j++) {
                arrCircle[j] = new MyCircle();
                arrCircle[j].getCenterCircl().setX(scan.nextDouble());
                arrCircle[j].getCenterCircl().setY(scan.nextDouble());
            }
            for (int h = 0; h < m; h++) {
                arrCircle[h].setRadius(scan.nextDouble());
            }
            int q = scan.nextInt();

            int i = scan.nextInt();
            int j = scan.nextInt();

            System.out.println("Case #" + index);
            System.out.printf("distance = %.3f\n", arr[k].getDistance(x1, y1));
            System.out.println(arr[p].toString());
            System.out.println(arrCircle[q].toString());
            double kc = arrCircle[i].getCenterCircl().getDistance(arrCircle[j].getCenterCircl().getX(), arrCircle[j].getCenterCircl().getY());
            double ri = arrCircle[i].getRadius();
            double rj = arrCircle[j].getRadius();
            if ((kc < (ri + rj) && kc > Math.abs(rj - ri)) || (kc == 0 && ri == rj) || (kc == (ri + rj)) || (kc == Math.abs(rj - ri))) {
                System.out.println("Circle " + i + " intersects with Circle " + j);

            } else if ((kc < (rj - ri) && rj > ri)) {
                System.out.println("Circle " + i + " is inside Circle " + j);
            } else{
                System.out.println("Circle " + j + " does not intersect Circle " + i);
            }
        }
    }
}
