/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_13;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Lab02_Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<Student> list = new ArrayList<>();
        int T = scan.nextInt();
        scan.nextLine();
        for(int i = 0;i<T;i++){
            String choose = scan.nextLine();
            if(choose.startsWith("1")){
                String[] arr = choose.split(" ");
                list.add(new Student(Integer.parseInt(arr[1]),arr[2],arr[3],LocalDate.parse(arr[4]),Double.parseDouble(arr[5])));               
            }else if(choose.startsWith("2")){
                String[] arr = choose.split(" ");
                if(arr[1].equals("1")){
                    for(int j = 0;j<list.size();j++){
                        if(arr[2].equals(list.get(j).getFirstName())){
                            list.remove(j);
                        }
                    }
                }else{
                    for(int j = 0;j<list.size();j++){
                        if(arr[2].equals(list.get(j).getLastName())){
                            list.remove(j);
                        }
                    }
                }
            }else if(choose.startsWith("3")){
                String[] arr = choose.split(" ");
                for(int j = 0;j<list.size();j++){
                    if(arr[1].equals(list.get(j).getId())){
                       if(arr[2].equals("1")){
                           list.get(j).setFirstName(arr[3]);
                       } else if(arr[2].equals("2")){
                           list.get(j).setLastName(arr[3]);
                       } else if(arr[2].equals("3")){
                           list.get(j).setBirthDay(LocalDate.parse(arr[3]));
                       } else if(arr[2].equals("4")){
                           list.get(j).setGpa(Double.parseDouble(arr[3]));
                       }
                    }
                }
            }else if(choose.startsWith("4")){
                String[] arr = choose.split(" ");
                if(arr[1].equals("1")){
                    list.sort(new LastNameComperator());
                }else if(arr[1].equals("2")){
                    list.sort(new AgeComperator());
                }else if(arr[1].equals("3")){
                    list.sort(new GPAComperator());
                }
            }else if(choose.startsWith("5")){
                for(int j = 0;j<list.size();j++){
                    if(j == 10) break;
                    System.out.println(list.get(j).toString());
                }
            }else if(choose.startsWith("6")){
                for(int j = 0;j<list.size();j++){
                    System.out.println(list.get(j).toString());
                }
            }
        }
    }
}
