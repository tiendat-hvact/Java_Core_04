/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_13;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;

/**
 *
 * @author ADMIN
 */
public class Student {

    private int id;
    private String firstName;
    private String lastName;
    private LocalDate birthDay;
    private double gpa;

    public Student(int id, String firstName, String lastName, LocalDate birthDay, double gpa) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDay = birthDay;
        this.gpa = gpa;
    }

    public String toString() {
        return "Student{id=" + this.id +", firstName="+this.firstName+", lastName="+this.lastName+", birthday="+this.birthDay.toString()+", GPA="+this.gpa+"}";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public LocalDate getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(LocalDate birthDay) {
        this.birthDay = birthDay;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

}

class AgeComperator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        int sort = o1.getBirthDay().compareTo(o2.getBirthDay());
        if (sort == 0) {

            int sort1 = o1.getLastName().compareTo(o2.getLastName());
            if (sort1 == 0) {
                int sort2 = o1.getFirstName().compareTo(o2.getFirstName());
                if (sort2 == 0) {
                    if (o1.getGpa() > o2.getGpa()) {
                        return 1;
                    }
                    if (o1.getGpa() < o2.getGpa()) {
                        return -1;
                    }
                    return 0;
                }
                return sort2;
            }
            return sort1;
        }
        return sort;
    }
}

class GPAComperator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {

        if (o1.getGpa() > o2.getGpa()) {
            return 1;
        }
        if (o1.getGpa() < o2.getGpa()) {
            return -1;
        }
        int sort = o1.getLastName().compareTo(o2.getLastName());
        if (sort == 0) {

            int sort1 = o1.getFirstName().compareTo(o2.getFirstName());
            if (sort1 == 0) {
                int sort2 = o1.getFirstName().compareTo(o2.getFirstName());
                if (sort2 == 0) {
                    return o1.getBirthDay().compareTo(o2.getBirthDay());

                }
                return sort2;
            }
            return sort1;
        }
        return sort;
    }
}

class FirstNameComperator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {

        return o1.getFirstName().compareTo(o2.getFirstName());

    }
}

class LastNameComperator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {

        int sort = o1.getLastName().compareTo(o2.getLastName());
        if (sort == 0) {

            int sort1 = o1.getFirstName().compareTo(o2.getFirstName());
            if (sort1 == 0) {
                int sort2 = o1.getFirstName().compareTo(o2.getFirstName());
                if (sort2 == 0) {
                    int sort3 = o1.getBirthDay().compareTo(o2.getBirthDay());
                    if (sort3 == 0) {
                        if (o1.getGpa() > o2.getGpa()) {
                            return 1;
                        }
                        if (o1.getGpa() < o2.getGpa()) {
                            return -1;
                        }
                        return 0;
                    }
                    return sort3;
                }
                return sort2;
            }
            return sort1;
        }
        return sort;
    }
}
