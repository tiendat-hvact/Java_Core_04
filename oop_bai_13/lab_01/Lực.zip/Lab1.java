/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson13.lab1;

import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class Lab1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList<Integer> list = new LinkedList<>();
        int N = sc.nextInt();
        sc.nextLine();
        int i, j;
        int lcs, X, Y, count;
        String lcc;
        String[] arr = new String[N];
        String[] a1;
        for (i = 0; i < N; i++) {
            arr[i] = sc.nextLine();
            a1 = arr[i].split(" ");
            lcs = Integer.parseInt(a1[0]);
            switch (lcs) {
                case 1 -> {
                    lcc = a1[1];
                    switch (lcc) {
                        case "F" -> {
                            X = Integer.parseInt(a1[2]);
                            list.add(0, X);
                    }
                        case "L" -> {
                            X = Integer.parseInt(a1[2]);
                            list.add(X);
                    }
                        case "P" -> {
                            Y = Integer.parseInt(a1[2]);
                            X = Integer.parseInt(a1[3]);
                            if (Y < list.size()) {
                                list.add(Y, X);
                            } else {
                                list.add(X);
                            }
                    }
                    }
                }
                case 2 -> {
                    X = Integer.parseInt(a1[1]);
                    count = 0;
                    for (j = list.size() - 1; j >= 0; j--) {
                        if (list.get(j) == X) {
                            count++;
                            list.remove(j);
                        }
                    }
                    System.out.println(count);
                }
                case 3 -> {
                    count = 0;
                    X = Integer.parseInt(a1[1]);
                    for (j = 0; j < list.size(); j++) {
                        if (list.get(j) == X) {
                            count++;
                        }
                    }
                    System.out.println(count);
                }
                case 4 -> {
                    X = Integer.parseInt(a1[1]);
                    Y = Integer.parseInt(a1[2]);
                    if (Y < list.size()) {
                        for (j = X; j <= Y; j++) {
                            System.out.print(list.get(j) + " ");
                        }
                    } else {
                        for (j = X; j < list.size(); j++) {
                            System.out.print(list.get(j) + " ");
                        }
                    }
                    System.out.println("");
                }
                case 5 -> {
                    for (j = 0; j < list.size(); j++) {
                        System.out.print(list.get(j) + " ");
                    }
                    System.out.println("");
                }
            }
        }
    }
}


