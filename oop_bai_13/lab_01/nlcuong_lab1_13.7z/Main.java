/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1_13;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<Integer> list = new ArrayList<Integer>();
        int T = scan.nextInt();
        scan.nextLine();
        for (int i = 0; i < T; i++) {
            String choose = scan.nextLine();
            if (choose.startsWith("1 F")) {
                int a = Integer.parseInt(String.valueOf(choose.charAt(4)));
                list.add(0, a);
            } else if (choose.startsWith("1 L")) {
                int a1 = Integer.parseInt(String.valueOf(choose.charAt(4)));
                list.add(a1);
            } else if (choose.startsWith("1 P")) {
                int a2 = Integer.parseInt(String.valueOf(choose.charAt(6)));
                int y = Integer.parseInt(String.valueOf(choose.charAt(4)));
                if (y >= list.size()) {
                    list.add(a2);
                } else {
                    list.add(y, a2);
                }
            } else if (choose.startsWith("2")) {
                int dem = 0;
                int a3 = Integer.parseInt(String.valueOf(choose.charAt(2)));
                for (int j = 0; j < list.size(); j++) {
                    if ((int) list.get(j) == a3) {
                        list.remove(j);
                        dem++;
                    }
                }
                System.out.println(dem);
            } else if (choose.startsWith("3")) {
                int dem = 0;
                int a4 = Integer.parseInt(String.valueOf(choose.charAt(2)));
                for (int j = 0; j < list.size(); j++) {
                    if ((int) list.get(j) == a4) {
                        dem++;
                    }
                }
                System.out.println(dem);
            } else if (choose.startsWith("4")) {
                int a5 = Integer.parseInt(String.valueOf(choose.charAt(2)));
                int y1 = Integer.parseInt(String.valueOf(choose.charAt(4)));
                for (int j = a5; j <= y1; j++) {
                    System.out.printf("%d ", (int) list.get(j));
                }
                System.out.println("");
            } else if (choose.startsWith("5")) {
                int dem = 0;
                int a6 = Integer.parseInt(choose);
                for (int j = 0; j < list.size(); j++) {
                    System.out.print(list.get(j).toString() + " ");
                }
                System.out.println("");
            }

        }
    }
}
