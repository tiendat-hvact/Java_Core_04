/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.les04;

import java.util.Scanner;

/**
 *
 * @author Mr.Nguyen
 */
public class bai7 {

    /**
     * @param args the command line arguments
     */
    public double chieu_dai;
    public double chieu_rong;

    public bai7() {
    }

    public bai7(double chieu_dai, double chieu_rong) {
        this.chieu_dai = chieu_dai;
        this.chieu_rong = chieu_rong;
    }

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhập chiều dài: ");
        this.chieu_dai = sc.nextDouble();
        System.out.println("nhập chiều rộng: ");
        this.chieu_rong = sc.nextDouble();
    }


    public void tinh_Cv() {
        System.out.printf("chu vi dinh chu nhật: %f\n", (this.chieu_dai + this.chieu_rong) * 2);
    }
    
    public void tinh_dien_tich() {
        System.out.printf("%f", this.chieu_dai * this.chieu_rong);
    }
}
