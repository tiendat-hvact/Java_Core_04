/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class TamGiac {
    public double cd;
    public double cr;
    public double cv;
    public double dt;
    public double p;
    public void nhap(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Nhập chiều dài");
        cd =sc.nextDouble();
        System.out.println("Nhập chiều rộng");
        cr = sc.nextDouble();    
    }
    public double tinhtoanchuvi(){
        this.cv=(this.cd+this.cr)*2;
        return this.cv ;
        
    }
    public double dientich(){
        this.dt = this.cd*this.cr;
        return this.dt;
    }
    public void xuat(){
        System.out.println("chu vi hcn là = "+this.cv);
        System.out.println("diện tích hcn là = "+this.dt);
    }
    
}
