/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab7;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Rectangle {

    private double a, b;

    public Rectangle() {
    }

    public Rectangle(double a, double b) {
        this.a = a;
        this.b = b;
    }

    public void nhap() {
        Scanner scan = new Scanner(System.in);

        do {
            this.a = scan.nextDouble();
            this.b = scan.nextDouble();
        } while (a <= 0 || b <= 0);
    }

    public double chuVi() {
        return 2 * (a + b);
    }

    public double dienTich() {
        return a * b;
    }
}
