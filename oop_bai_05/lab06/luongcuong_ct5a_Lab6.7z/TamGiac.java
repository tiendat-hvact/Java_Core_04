/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab6;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class TamGiac {

    private double a, b, c;

    public TamGiac() {
    }

    public TamGiac(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public void nhap() {
        Scanner scan = new Scanner(System.in);

        do {
            a = scan.nextDouble();
            b = scan.nextDouble();
            c = scan.nextDouble();
        } while (a <= 0 || b <= 0 || c <= 0 || (a + b <= c) || (a + c <= b) || (c + b <= a));
    }

    public void xacDinh() {
        if ((a == b) || (b == c) || (a == c)) {
            if ((b == c) && (a == c)) {
                System.out.println("Tam giac deu");
            } else if ((a * a + b * b == c * c) || (a * a + c * c == b * b) || (c * c + b * b == a * a)) {
                System.out.println("Tam giac vuong can");
            } else {
                System.out.println("Tam giac can");
            }
        } else if ((a * a + b * b == c * c) || (a * a + c * c == b * b) || (c * c + b * b == a * a)) {
            System.out.println("Tam giac vuong");
        } else {
            System.out.println("Tam giac thuong");
        }
    }

    public double ChuVi() {
        return this.a + this.b + this.c;
    }

    public double DienTich() {
        double p = ChuVi() / 2;
        return Math.sqrt(p * (p - this.a) * (p - this.b) * (p - this.c));
    }
}
