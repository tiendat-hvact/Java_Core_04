/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class TamGiac {
    public double a;
    public double b;
    public double c;
    public double cv;
    public double dt;
    public double p;
    public void nhapDoDai3canh(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập Độ Dài Cạnh a");
        this.a = sc.nextDouble();
         System.out.println("Nhập Độ Dài Cạnh b");
        this.b = sc.nextDouble();
         System.out.println("Nhập Độ Dài Cạnh c");
        this.c =sc.nextDouble();
                
    }
    public void xacDinhLoaiTamGiac(){
        if (this.a == this.c &&this.a==this.b &&this.b == this.c) {
            System.out.println("Tam giác này là tam giac đều ");
        }else if ((this.a == this.b&&this.b != this.c)||(this.a==this.c &&this.b!= this.c)||(this.c==this.b &&this.b != this.a)) {
            System.out.println("Tam Giac nay la tam giac cân");       
        }else if ((this.a*this.a==this.b*this.b+this.c*this.c)||(this.b*this.b==this.a*this.a+this.c*this.c)||(this.c*this.c==this.b*this.b+this.a*this.a)) {
            System.out.println("Tam Giac này là Tam giác Vuông");      
        }
    }
    public double TinhChuViTamGiac(){
        if((this.a !=this.b+this.c)&&(this.b !=this.a+this.c)&&(this.c !=this.a+this.b))
            this.cv = this.a+this.b+this.c;
                   return cv;
    }
    public double TinhDienTich(){
         if((this.a !=this.b+this.c)&&(this.b !=this.a+this.c)&&(this.c !=this.a+this.b))
             this.p = (this.a+this.b+this.c)/2;
             this.dt=(double)Math.sqrt(this.p*(this.p-this.a)*(this.p-this.b)*(this.p-this.c));
             return dt;
    }
    public void outPut(){
        System.out.println("Thông Tin Tam Giac");
        System.out.println("cạnh a ="+this.a);
        System.out.println("cạnh b ="+this.b);
        System.out.println("cạnh c ="+this.c);
        System.out.println("chu vi Tam giac là"+this.cv);
        System.out.println("diện tích Tam giác là:"+this.dt);
        
    }
}
