/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6;

/**
 *
 * @author Luc
 */
public class Main {
    public static void main(String[] args) {
        TamGiac abc=new TamGiac();
        abc.nhapDoDai3canh();
        abc.TinhChuViTamGiac();
        abc.TinhDienTich();
        abc.outPut();
        abc.xacDinhLoaiTamGiac();
    }
    
}
