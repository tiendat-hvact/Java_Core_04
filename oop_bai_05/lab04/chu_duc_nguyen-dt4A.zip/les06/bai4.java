/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.les06;

import java.util.Scanner;

/**
 *
 * @author Mr.Nguyen
 */
public class bai4 {

    public String ho_ten;
    public String nam_sinh;
    public String dia_chi;
    public double tien_luong;
    public int gio_lam;

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.print("nhập tên nhân viên: ");
        this.ho_ten = sc.nextLine();
        System.out.print("nhập năm sinh nhân viên: ");
        this.nam_sinh = sc.nextLine();
        System.out.print("nhập địa chỉ nhân viên: ");
        this.dia_chi = sc.nextLine();
        System.out.print("nhập giờ làm: ");
        this.gio_lam = sc.nextInt();
        System.out.print("nhập tiền lương: ");
        this.tien_luong = sc.nextDouble();
    }

    public void output() {
        System.out.printf(" tên nhân viên là: %s\n", this.ho_ten);
        System.out.printf("năm sinh của nhân viên là: %s \n",this.nam_sinh);
        System.out.printf("địa chỉ nhân viên: %s\n", this.dia_chi);
        System.out.printf("giờ lam:%d\n", this.gio_lam);
        this.tien_luong += tien_thuong();
        System.out.printf("tiền lương sẽ là: %f\n", this.tien_luong);
    }

    public double tien_thuong() {
        if (gio_lam >= 200) {
            this.tien_luong = tien_luong * 0.2;
        }
        if (100 <= gio_lam && gio_lam < 200) {
            this.tien_luong = tien_luong * 0.1;
        } else {
            this.tien_luong = tien_luong*1;
        }
        return tien_luong;
    }

    public static void main(String[] args) {
        // TODO code application logic here

    }

}
