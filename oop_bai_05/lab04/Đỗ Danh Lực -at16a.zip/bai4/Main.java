/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4;

/**
 *
 * @author Luc
 */
public class Main {
    public static void main(String[] args) {
        NhanVien vn = new NhanVien();
        vn.inputInfo();
        vn.tinhThuong();
        vn.prinfInfo();
    }
}
