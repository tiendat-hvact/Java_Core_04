/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class NhanVien {
    public String hovaten;
    public float namsinh;
    public String diachi;
    public double tienluong;
    public int tonggiolamviec;
    public double thuong;

    public void inputInfo(){
         Scanner sc= new Scanner (System.in);
         System.out.println("Nhập Họ Và Tên");
         this.hovaten = sc.nextLine();
         System.out.println("Nhập Nam Sinh");
         this.namsinh = sc.nextFloat();
         sc.nextLine();
         System.out.println("Nhập địa chỉ");
         this.diachi = sc.nextLine();
         System.out.println("Tiền Lương");
         this.tienluong = sc.nextDouble();
         System.out.println("Tổng giờ làm việc");
         this.tonggiolamviec = sc.nextInt();
    }
    public double tinhThuong(){
        if (this.tonggiolamviec >=200) {
           this.thuong =this.tienluong*0.2;
        }else if (this.tonggiolamviec <200 && this.tonggiolamviec>=100){
            this.thuong = this.tienluong*02;
        }else if (this.tonggiolamviec<100){
            this.thuong = 0;
            
        }
     return thuong;
    } 
    public void prinfInfo (){
        System.out.println("Họ và Tên");
        System.out.println(this.hovaten);
        System.out.println("Năm Sinh");
        System.out.println(this.namsinh);
        System.out.println("Địa Chủ");
        System.out.println(this.diachi);
        System.out.println("Lương");
        double c = this.thuong+this.tienluong;
        System.out.println("Tiền Lương ="+c);
    }
}
   
       
