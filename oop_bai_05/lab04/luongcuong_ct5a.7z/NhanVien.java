/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class NhanVien {
    String hoTen;
    int namSinh;
    String diaChi;
    double luong;
    int gioLam;
    
    public NhanVien(){
    }
    
    public NhanVien(String hoTen, int namSinh, String diaChi, double luong, int gioLam)
    {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.diaChi = diaChi;
        this.luong = luong;
        this.gioLam = gioLam;
    }
    
    public void inputInfo()
    {
        Scanner scan = new Scanner(System.in);
        
        this.hoTen = scan.nextLine();
        this.namSinh = Integer.parseInt(scan.nextLine());
        this.diaChi = scan.nextLine();
    }
    
    public void prinfInfo()
    {
        System.out.println("Ho ten la: " + this.hoTen);
        System.out.println("Nam sinh la: " + this.namSinh);
        System.out.println("Dia chi la: " + this.diaChi);
    }
        
    public double tinhThuong()
    {
        if(this.gioLam >= 200)
        {
            return this.luong/5;
        }
        else if(this.gioLam >= 100)
        {
            return this.luong/10;
        }
        else{
            return 0;
        }
    }
}
