/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.les05.lab1;

import java.util.Scanner;

/**
 *
 * @author Mr.Nguyen
 */
public class HoTen {

    /**
     * @param args the command line arguments
     */
    public String hoten;
    public String ThongTinHocSinh;
    
    public void input(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println(">> ho ten: ");
        this.hoten = sc.nextLine();
        System.out.println("hoc sinh: ");
        this.ThongTinHocSinh = sc.nextLine();
    }
    public void output(){
        System.out.println("=============");
        System.out.println("thong tin hoc sinh");
        System.out.println(this.hoten);
        System.out.println(this.ThongTinHocSinh);
    }
    public static void main(String[] args) {
        // TODO code application logic here
    }
 
    
}
