/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.les05.lab1;

/**
 *
 * @author Mr.Nguyen
 */
public class Solution {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        HoTen HocSinh = new HoTen();
        
        HocSinh.input();
        HocSinh.output();
        
    }
    
}
