/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab9;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class MaTran {

    private int hang, cot;
    private int[][] arr;

    public MaTran() {
    }

    public MaTran(int hang, int cot) {
        this.hang = hang;
        this.cot = cot;
        this.arr = new int[hang][cot];
    }

    public void Nhap() {
        Scanner scan = new Scanner(System.in);

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                arr[i][j] = scan.nextInt();
            }
        }
    }

    public void Xuat() {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                System.out.printf(arr[i][j] + " ");
            }
            System.out.println("");
        }
    }

    public void xoayPhai90() {
        int[][] b = new int[this.cot][this.hang];

        for (int i = 0; i < b.length; i++) {
            for (int j = 0; j < b[0].length; j++) {
                
                b[i][j] = arr[this.hang - 1 - j][i];
                System.out.print(b[i][j]);
            }
            System.out.println("");
        }
    }

    public void xoayTrai90() {
        int[][] b = new int[cot][hang];

        for (int i = 0; i < b.length; i++) {
            for (int j = 0; j < b[0].length; j++) {
                b[i][j] = arr[j][cot - 1 - i];
                System.out.print(b[i][j]);
            }
            System.out.println("");
        }
    }

    public void xoay180() {
        int[][] b = new int[hang][cot];

        for (int i = 0; i < b.length; i++) {
            for (int j = 0; j < b[0].length; j++) {
                b[i][j] = arr[hang - 1 - i][cot - 1 - j];
                System.out.print(b[i][j]);
            }
            System.out.println("");
        }
    }
}
