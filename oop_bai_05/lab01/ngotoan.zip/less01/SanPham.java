/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package less01;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class SanPham {
    public String enSanPham;
    public double giamGia;
    public double donGia;
    public double thueGiamGia;
    public  void nhap(){
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap ten san pham");
        this.enSanPham=sc.nextLine();
        System.out.println("nhap don gia");
        this.donGia=sc.nextDouble();
        System.out.println("nhap giam gia");
        this.giamGia=sc.nextDouble();
    }
    public void xuat(){
        System.out.printf("ten san pham: %s\n",this.enSanPham);
        System.out.printf("don gia: %.2f\n",this.donGia);
        System.out.printf("giam gia: %.2f\n",this.giamGia);
        this.thueGiamGia=getThueNhapKhau();
       System.out.printf("thue nhap khau: %.2f\n",this.thueGiamGia);
    }
        
    
    public double getThueNhapKhau(){
        this.thueGiamGia=donGia*0.1;
        return thueGiamGia;
    }

    
}
