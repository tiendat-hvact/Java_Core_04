/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basuc.les05.lab4.newpackage;

import java.util.Scanner;

/**
 *
 * @author Mr.Nguyen
 */
public class SanPham {

    /**
     * @param args the command line arguments
     */
    public String TenSanPham;
    public double DonGia;
    public double giamGia;
    public double thueNk;

    public void input() {
         Scanner sc = new Scanner(System.in);
         System.out.print("nhap ten sp: ");
         this.TenSanPham = sc.nextLine();
         System.out.print("nhap don gia:  ");
         this.DonGia = sc.nextDouble();
         System.out.print("nhap giam gia:  ");
         this.giamGia = sc.nextDouble();
    }

    public void output() {
        System.out.printf("ten san pham: %s\n",this.TenSanPham);
        System.out.printf("don gia: %.2f\n",this.DonGia);
        System.out.printf("giam gia: %.2f\n",this.giamGia);
        this.thueNk  = getThueNhapKhau();
        System.out.printf("thue nhap khau: %.2f\n",this.thueNk);
    }

    public double getThueNhapKhau() {
        this.thueNk = DonGia * 0.1;
        return thueNk;
    }

    public static void main(String[] args) {
        // TODO code application logic here
    }

}
