/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab1;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class SanPham {
    private String ten;
    private double gia;
    private double giamGia;

    public SanPham() {
    }
    
    public void Nhap()
    {
        Scanner scan = new Scanner(System.in);
        
        this.ten = scan.nextLine();
        this.gia = scan.nextDouble();
        this.giamGia = scan.nextDouble();
    }
    
    public void Xuat()
    {
        System.out.println("Ten san pham: " + this.ten);
        System.out.println("Gia san pham: " + this.gia);
        System.out.println("Giam gia: " + this.giamGia);
        System.out.println("Thue san pham: " + getThueNhapKhau());
        
    }
    
    public double getThueNhapKhau()
    {
        return gia*0.1;
    }
}
