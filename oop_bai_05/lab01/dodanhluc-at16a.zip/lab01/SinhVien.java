/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson05.lab01;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class SinhVien {

    private String name;
    private String lop;
    private double dtb;

    public SinhVien(String a, String b, double c) {
        this.name = a;
        this.lop = b;
        this.dtb = c;

    }

    public SinhVien() {

    }

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Họ Và Tên");
        this.name = sc.nextLine();
        System.out.println("Lớp");
        this.lop = sc.nextLine();
        System.out.println("DTB");
        this.dtb = sc.nextDouble();
    }
  

    public void output() {
        System.out.println("nhap thong tin");
        System.out.println(this.name);
        System.out.println(this.lop);
        System.out.println("điểm trung bình");
        System.out.println(this.dtb);

        if (this.dtb < 4) {
            System.out.println("học lại");
        }
        if (this.dtb < 5.4 && this.dtb >= 4.0) {
            System.out.println("Trung bình");
        }
        if (this.dtb <= 6.9 && this.dtb >= 5.5) {
            System.out.println("trung binh kha");

        }
        if (this.dtb <= 7.0 && this.dtb >= 7.9) {
            System.out.println("khá");

        }
        if (this.dtb >= 8.0 &&this. dtb <= 10) {
            System.out.println("giỏi");

        }
    }
}
