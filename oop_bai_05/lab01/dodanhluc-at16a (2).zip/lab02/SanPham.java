/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson05.lab02;

import static java.lang.reflect.Array.get;
import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class SanPham {
   public String tensanpham;
   public double dongia;
   public double giamgia;
   public double thuenhapkhau;
   public void nhap(){
       Scanner sc = new Scanner (System.in);
       this.tensanpham= sc.nextLine();
       this.giamgia = sc.nextDouble();
       this.dongia = sc.nextDouble();
       this.thuenhapkhau =sc.nextDouble();
       
   }
   public double  getthueNk(){
    this.thuenhapkhau= dongia*0.1;
           
       
       return thuenhapkhau;
       
   }
   public void xuat(){
       System.out.println(this.tensanpham);
       System.out.println(this.giamgia);
       System.out.println(this.dongia);
       this.thuenhapkhau=getthueNk();
       System.out.println(this.thuenhapkhau);
       
   }
       
   }

