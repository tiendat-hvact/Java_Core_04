/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson05.lab04;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class SanPham {
      public String tensanpham;
   public double dongia;
   public double giamgia;
   public double thuenhapkhau;

    public SanPham(String tensanpham, double dongia, double giamgia) {
        this.tensanpham = tensanpham;
        this.dongia = dongia;
        this.giamgia = giamgia;
    }

    public SanPham(String tensanpham, double dongia) {
        this.tensanpham = tensanpham;
        this.dongia = dongia;
    }
  
   public void nhap(){
       Scanner sc = new Scanner (System.in);
       this.tensanpham= sc.nextLine();
       this.giamgia = sc.nextDouble();
       this.dongia = sc.nextDouble();
       this.thuenhapkhau =sc.nextDouble();
       
   }
   private double  getthueNk(){
    this.thuenhapkhau= dongia*0.1;
           
       
       return thuenhapkhau;
       
   }
   public void xuat(){
       System.out.println(this.tensanpham);
      
       System.out.printf("%2f\n",this.dongia);
        System.out.printf("%2f\n",this.giamgia);
       this.thuenhapkhau=getthueNk();
       System.out.printf("%2f\n",this.thuenhapkhau);
       
   }
       
   }

    

