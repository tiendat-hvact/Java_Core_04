/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson05.lab04;

/**
 *
 * @author Luc
 */
public class Main {
    public static void main(String[] args) {
        SanPham sp1 = new SanPham ("lao" ,10000.0,1000.0);
        SanPham  sp2 = new SanPham("dia",6000.0);
        sp1.xuat();
        sp2.xuat();
    }
    
}
