/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package less01;

/**
 *
 * @author Student
 */
public class Main {
    public static void main(String[] args) {
        SanPham s= new SanPham();
        SanPham sp1=new SanPham("sp1", 3);
        SanPham sp2= new SanPham("sp2", 4, 0);
        s.nhap();
        s.xuat();
        sp1.xuat();
        sp2.xuat();
    }
   
    
    
        
    
}
