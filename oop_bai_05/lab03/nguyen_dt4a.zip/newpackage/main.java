/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basuc.les05.lab6.newpackage;

import javacore.basuc.les05.lab6.newpackage.SanPham;

/**
 *
 * @author Mr.Nguyen
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       SanPham p = new SanPham("dao",1000.0 ,1000.0);
       SanPham p2 = new SanPham("dao",100.0);
        p.output();
        p2.output();
    }
    
}
