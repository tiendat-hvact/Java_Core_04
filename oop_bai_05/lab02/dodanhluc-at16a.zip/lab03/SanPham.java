/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson05.lab03;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class SanPham {
       public String tensanpham;
   public double dongia;
   public double giamgia;
   public double thuenhapkhau;
   public void nhap(){
       Scanner sc = new Scanner (System.in);
       this.tensanpham= sc.nextLine();
       this.giamgia = sc.nextDouble();
       this.dongia = sc.nextDouble();
       
   }

  
   
           
      public void xuat(){
       System.out.println(this.tensanpham);
       System.out.printf("%2f\n",this.giamgia);
       System.out.printf("%2f\n",this.dongia);
       
       
   }
}
