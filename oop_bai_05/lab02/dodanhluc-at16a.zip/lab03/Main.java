/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson05.lab03;

/**
 *
 * @author Luc
 */
public class Main {
    public static void main(String[] args) {
         SanPham sp1 = new SanPham( );
         SanPham sp2 = new SanPham();
        sp1.nhap();
        sp1.xuat();
        sp2.nhap();
        sp2.xuat();
    }
    
}
