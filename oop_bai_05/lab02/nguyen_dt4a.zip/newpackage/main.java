/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basuc.les05.lab5.newpackage;

import javacore.basuc.les05.lab4.newpackage.SanPham;

/**
 *
 * @author Mr.Nguyen
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SanPham2 sp1 = new SanPham2();
        SanPham2 sp2 = new SanPham2();
        sp1.input();
        sp2.input();
        sp1.output();

        sp2.output();

    }

}
