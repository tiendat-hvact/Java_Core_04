/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basuc.les05.lab5.newpackage;

import java.util.Scanner;

/**
 *
 * @author Mr.Nguyen
 */
public class SanPham2 {

    /**
     * @param args the command line arguments
     */
    public String TenSanpham;
    public double DonGia;

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhập tên sản phẩm: ");
        this.TenSanpham = sc.nextLine();
        System.out.println("Đơn Giá: ");
        this.DonGia = sc.nextDouble();
    }

    public void output() {
        System.out.printf("ten san pham: %s\n", this.TenSanpham);
        System.out.printf("don gia: %.2f\n", this.DonGia);
    }

    public static void main(String[] args) {
        // TODO code application logic here
    }

}
