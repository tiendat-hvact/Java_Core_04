/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab5;

import java.net.IDN;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Student {

    private String id;
    private double dtb;
    private int namSinh;
    private String lop;

    public Student() {
    }

    public Student(String id, double dtb, int namSinh, String lop) {
        if (id.length() == 8) {
            this.id = id;
        }
        if (dtb >= 0.0 && dtb <= 10.0) {
            this.dtb = dtb;
        }
        if (namSinh >= 2002) {
            this.namSinh = namSinh;
        }
        if (lop.charAt(0) == 'A' || lop.charAt(0) == 'C' || lop.charAt(0) == 'D') {
            this.lop = lop;
        }
    }

    public void inputInfo() {
        Scanner scan = new Scanner(System.in);
        
        int dem = 1;
        do {
            
            if(dem == 2)
            {
                System.out.println("Vui long nhap lai thong tin");
            }
            
            this.id = scan.nextLine();
            this.dtb = scan.nextDouble();
            this.namSinh = Integer.parseInt(scan.nextLine());
            this.lop = scan.nextLine();
            dem = 2;
            
        } while ((this.id.length() != 8)||(dtb < 0.0 && dtb > 10.0)||(namSinh < 2002)||(lop.charAt(0) != 'A' && lop.charAt(0) != 'C' && lop.charAt(0) != 'D'));
    }
    
    public void showInfo()
    {
        System.out.println("Ma sinh vien la: " + this.id);
        System.out.println("Diem trung binh la: " + this.dtb);
        System.out.println("Nam sinh la: " + this.namSinh);
        System.out.println("Lop la: " + this.lop);
        
    }
    
    public boolean checkScholarship()
    {
        if(this.dtb >= 8.0)
        {
            return true;
        }
        return false;
    }
}
