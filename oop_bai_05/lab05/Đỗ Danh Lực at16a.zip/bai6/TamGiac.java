/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class TamGiac {
    public String masinhvien;
    public double diemtrungbinh;
    public int namsinh;
    public String lop;
    public void inputInfo(){
        Scanner sc=new  Scanner(System.in);
        System.out.println("Nhập Mã Sinh Viên");
        this.masinhvien = sc.nextLine();
        System.out.println("Nhập điểm trung bình");
        this.diemtrungbinh = sc.nextDouble();
        System.out.println("Nhập Năm sinh");
        this.namsinh = sc.nextInt();
        System.out.println("Nhập Lớp");
        this.lop = sc.nextLine();          
    }
    public void checkScholarship(){
        if (this.diemtrungbinh>=8.0){
            System.out.println("Học Bổng:Yes");   
        }else{
            System.out.println("Học Bổng:No");
        }
    }
    public void printInfo(){
            System.out.println(this.masinhvien); 
        if (this.diemtrungbinh>=0.0&&this.diemtrungbinh<=10.0) {
            System.out.println(this.diemtrungbinh);    
        }
        if (this.namsinh >=2002) {
            System.out.println(this.namsinh); 
        }
        for(int i = 0; i < lop.length();i++){
	char kyTu = lop.charAt(i);
	if(kyTu >= 'A'||kyTu >='C' ||kyTu >= 'D'){
            System.out.println(this.lop);
            
        }
        }
     
     
         
     }
    
}
