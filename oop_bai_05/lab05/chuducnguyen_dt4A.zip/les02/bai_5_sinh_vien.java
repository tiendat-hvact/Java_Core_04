/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.les02;

import java.util.Scanner;

/**
 *
 * @author Mr.Nguyen
 */
public class bai_7_sinh_vien {

    /**
     * @param args the command line arguments
     */
    public String ma_sv;
    public double diem_tb;
    public int nam_sinh;
    public String lop;

    bai_7_sinh_vien() {}
        

    /**
     *
     */
   

    public bai_7_sinh_vien(String ma_sv, double diem_tb, int nam_sinh, String lop) {
        this.ma_sv = ma_sv;
        this.diem_tb = diem_tb;
        this.nam_sinh = nam_sinh;
        this.lop = lop;
    }

    public void input() {
        Scanner sc = new Scanner(System.in);
        System.out.print("nhập lớp: ");
        this.lop = sc.nextLine();
        System.out.print("nhập mã sinh viên: ");
        this.ma_sv = sc.nextLine();
        System.out.print("nhập năm sinh: ");
        this.nam_sinh = sc.nextInt();
        System.out.print("nhập điểm trung bình: ");
        this.diem_tb = sc.nextDouble();
    }

    public boolean check() {
// flag là cờ khi ta dựng nó lên nếu 1 trong các đk đúng thid nó vẫn i ra 
        boolean flag = false;
    //string charAt(index i) ABC123 khi đó  index bằng 3 nó sẽ vào chữ '2'
    // ở đay ta dùng nháy kép vì nháy đơn ta dùng cho chuỗi còn ở đây là kí tự
        char a = this.lop.charAt(0);
        if (a == 'A' && a == 'C' && a == 'D') {
            System.out.println("lop khong hop le");
            flag = false;
        }
        if (this.ma_sv.length() != 8) {
            System.out.println("ma sinh vien khong hop le");
            flag = false;
        }
        if (this.diem_tb < 0.0 || this.diem_tb > 10.0) {
            System.out.println("diem khong hop le");
            flag = false;
        }
        if (this.nam_sinh < 2002) {
            System.out.println("nam sinnh khong hoop le ");
            flag = false;
        }
        if (flag = false) {
            return true;
        } else {
            return false;
        }
    }

    public boolean hoc_bong() {
        if (this.diem_tb >= 8.0){
            return true;
        }else{
            return false;
        }            
    }

    public void output() {
        System.out.println("lớp sinh viên đó là: " + this.lop);
        System.out.println("mã sinh viên là: " + this.ma_sv);
        System.out.println("năm sinh là: " + this.nam_sinh);
        System.out.println("điểm trung bình là: " + this.diem_tb);
        System.out.println("dat học bổng:" +this.hoc_bong());
    }
}
