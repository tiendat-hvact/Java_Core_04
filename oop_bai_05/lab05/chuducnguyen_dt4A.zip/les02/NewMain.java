/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.les02;

import javacore.basic.les01.bai4;

/**
 *
 * @author Mr.Nguyen
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        bai_7_sinh_vien nv1 = new bai_7_sinh_vien();
        nv1.input();
        // nhạp sai 1 cái thì sẽ khong in thong tin các cái còn lại
        nv1.check();
        nv1.output();
        // nâng cao hơn thì nhập cho đến khi nào nó đúng khi đó dùng do - whlie.   

    }

}
