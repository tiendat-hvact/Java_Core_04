/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.les05;

import javacore.basic.les01.bai4;

/**
 *
 * @author Mr.Nguyen
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        bai_8 nv = new bai_8();
        nv.nhap_phan_so();
        nv.rut_gon();
        nv.hien_thi();
        nv.nghich_dao();
    }
    
}
