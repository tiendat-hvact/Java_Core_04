/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.les05;

import java.util.Scanner;

/**
 *
 * @author Mr.Nguyen
 */
public class bai_8 {

    public int tuso;
    public int mauSo;

    public bai_8() {
    }

    public bai_8(int tuso, int mauSo) {
        this.tuso = tuso;
        this.mauSo = mauSo;
    }

    public void nhap_phan_so() {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap tử số:");
        this.tuso = sc.nextInt();
        System.out.println("nhap mẫu số: ");
        this.mauSo = sc.nextInt();
    }

    public int UCLN() {
        int a, b;
        b = mauSo;
        a = tuso;
        int uc = 0;
        if (a == 0 && b == 0) {
            uc = a + b;
        } else {
            while (a != b) {
                if (a > b) {
                    a = a - b;
                } else {
                    b = b - a;
                }
            }
            uc = a;
        }
        return uc;
    }
    public void rut_gon(){
       int uc = UCLN();
          System.out.printf(" sau khi rút gon: %d/%d\n",tuso/uc,mauSo/uc);
    }
    public void hien_thi(){
        System.out.printf("phân số lúc đầu là: %d/%d\n",tuso,mauSo);
    }
    
    public void nghich_dao(){
        UCLN();
        int uc = UCLN();
        System.out.printf("phân số nghịch đảo rút gọn: %d/%d\n",mauSo/uc,tuso/uc);
    }
}
