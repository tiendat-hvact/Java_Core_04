/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8;

/**
 *
 * @author Luc
 */
public class Main {
      
    public static void main(String[] args) {
        // TODO code application logic here
        PhanSo nv = new PhanSo();
        nv.nhap_phan_so();
        nv.rut_gon();
        nv.hien_thi();
        nv.nghich_dao();
    }
    
    
}
