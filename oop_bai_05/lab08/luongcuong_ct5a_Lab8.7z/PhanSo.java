/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab8;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class PhanSo {

    private int tu;
    private int mau;

    public PhanSo() {
    }

    public PhanSo(int tu, int mau) {
        this.tu = tu;
        this.mau = mau;
    }

    public void nhap() {
        Scanner scan = new Scanner(System.in);

        this.tu = scan.nextInt();
        do {
            this.mau = scan.nextInt();
        } while (this.mau == 0);
    }

    private int ucln(int a, int b) {
        int min = a;
        int uoc = 1;
        if (a > b) {
            min = b;
        }
        for (int i = 1; i <= min; i++) {

            if (a % i == 0 && b % i == 0) {
                uoc = i;
            }

        }
        return uoc;
    }

    public void rutGon() {
        if (tu == 0 && mau != 0) {
            System.out.println("0");
        } else if (tu > mau && tu % mau == 0) {
            System.out.println(tu / mau);
        } else {
            int ucln = ucln(tu, mau);
            tu = tu / ucln;
            mau = mau / ucln;
            System.out.println(tu + "/" + mau);
        }
    }

    public void In() {
        if (tu == 0 && mau != 0) {
            System.out.println("0");
        } else {
            System.out.println(tu + "/" + mau);
        }
    }

    public void Dao() {
        if (tu == 0) {
            System.out.println("0");
        } else {
            System.out.println(mau + "/" + tu);
        }
    }
}
