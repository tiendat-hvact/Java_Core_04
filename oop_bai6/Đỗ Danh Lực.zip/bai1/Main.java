/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson06.bai1;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class Main {
 public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for (int i = 1; i <= T; i++) {
            int n = sc.nextInt();
            double[] arr = new double[n];
            for (int j = 0; j < n; j++) {
                arr[j] = sc.nextDouble();
            }
            sc.nextLine();
            String str1 = sc.nextLine();
            String str2 = sc.nextLine();
            int k = sc.nextInt();
            System.out.printf("Case #%d:\n", i);
            System.out.printf("Sum: %.2f\n", Paractice.Sum(arr));
            System.out.printf("Min: %f\n", Paractice.getMin(arr));
            System.out.printf("Max: %f\n", Paractice.getMax(arr));
            System.out.println("To upper: " + Paractice.toUpper(str1));
            System.out.println("To lower: " + Paractice.toLower(str2));
            System.out.println("To upper first char: " + Paractice.toUpperFirstChar(str1) + " - " + Paractice.toUpperFirstChar(str2));
            System.out.printf("Fibonacci(%d): %d\n", k, Paractice.getFibonacci(k));
        }
    }
}
