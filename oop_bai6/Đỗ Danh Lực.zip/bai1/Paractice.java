/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson06.bai1;

/**
 *
 * @author Luc
 */
public class Paractice {

    public static final double Sum(double[] x) {
        double sum = 0;
        for (double a : x) {
            sum += a;
        }
        return sum;
    }
    public static final double getMin(double[] x) {
        double min = x[0];
        for (double a : x) {
            if (min > a) {
                min = a;
            }
        }
        return min;
    }
    public static final double getMax(double[] x) {
        double max = x[0];
        for (double a : x) {
            if (max < a) {
                max = a;
            }
        }
        return max;
    }
    public static String toUpper(String str) {
        int i;
        char c;
        String s = "";
        for (i = 0; i < str.length(); i++) {
            c = str.charAt(i);
            int a = (int) c;
            if (a >= 97 && a <= 122) {
                a -= 32;
            }
            c = (char) a;
            s += c;
        }
        return s;
    }
    public static String toLower(String str) {
        int i;
        char c;
        String s = "";
        for (i = 0; i < str.length(); i++) {
            c = str.charAt(i);
            int a = (int) c;
            if (a <= 90 && a >= 65) {
                a += 32;
            }
            c = (char) a;
            s += c;
        }
        return s;
    }
    public static String toUpperFirstChar(String str) {
        str = str.toLowerCase();
        String[] words = str.split(" ");
        for (int i = 0; i < words.length; i++) {
            char firstChar = words[i].charAt(0);
            char upperFirstChar = String.valueOf(firstChar).toUpperCase().charAt(0);
            words[i] = upperFirstChar + words[i].substring(1);
        }
        String result = String.join(" ", words);
        return result;
    }
    public static long getFibonacci(int position) {
        if (position == 1 || position == 2) {
            return 1;
        } else {
            long ln = getFibonacci(position - 1) + getFibonacci(position - 2);
            return ln;
        }
    }
}
