/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.lesson06;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Solution {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        int T = scan.nextInt();
        int n,k;
        
        for(int i = 1; i<= T;i++)
        {
            n = scan.nextInt();
            double[] arr = new double[n];

            for(int j = 0;j<arr.length;j++)
            {
                arr[j] = scan.nextDouble();
            }
            scan.nextLine();
            
            String a = scan.nextLine();
            
            String b = scan.nextLine();
            k = scan.nextInt();
            
            System.out.printf("Case #%d:\n",i);
            double sum = Paractice.sum(arr);
            System.out.printf("Sum: %.2f\n",sum);
            
            double min = Paractice.min(arr);
            System.out.printf("Min: %.1f\n",min);
            
            double max = Paractice.max(arr);
            System.out.printf("Max: %.1f\n",max);
            
            String a1 = Paractice.toUpper(a);
            System.out.println("To upper: " + a1);
            
            String b1 = Paractice.toLower(b);
            System.out.println("To lower: " + b1);
            
            String a2 = Paractice.toUpperFirstChar(a);           
            String b2 = Paractice.toUpperFirstChar(b);
            System.out.println("To upper first char: " + a2 + " - " + b2);
            
            int finabo = Paractice.Fibonacci(k);
            System.out.printf("Fibonacci(%d): %d\n", k, finabo);
        }
    }
}
