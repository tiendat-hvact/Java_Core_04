/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.lesson06;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Solution {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        int T = Integer.parseInt(scan.nextLine());
        
        for(int i = 1; i<= T;i++)
        {
            int n = Integer.parseInt(scan.nextLine());
            double[] arr = new double[n];

            for(int j = 0;j<arr.length;j++)
            {
                arr[j] = Double.parseDouble(scan.nextLine());
            }
            
            String a = scan.nextLine();
            
            String b = scan.nextLine();
            int k = scan.nextInt();
            
            System.out.println(i);
            double sum = Paractice.sum(arr);
            System.out.println(sum);
            
            double min = Paractice.min(arr);
            System.out.println(min);
            
            double max = Paractice.max(arr);
            System.out.println(max);
            
            String a1 = Paractice.toUpper(a);
            System.out.println(a1);
            
            String b1 = Paractice.toLower(b);
            System.out.println(b1);
            
            String a2 = Paractice.toUpperFirstChar(a);           
            System.out.print(a2 + " - ");
            String b2 = Paractice.toUpperFirstChar(b);
            System.out.println(b2);
            
            int finabo = Paractice.Fibonacci(k);
            System.out.println(finabo);
            
        }
    }
}
