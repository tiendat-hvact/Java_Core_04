/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.basic.lesson06;

/**
 *
 * @author ADMIN
 */
public class Paractice {

    public static double sum(double... arr) {
        double tong = 0;
        for (double i : arr) {
            tong = tong + i;
        }
        return tong;
    }

    public static double max(double... arr) {
        double max = arr[0];

        for (double i : arr) {
            if (max < i) {
                max = i;
            }
        }
        return max;
    }

    public static double min(double... arr) {
        double max = arr[0];

        for (double i : arr) {
            if (max > i) {
                max = i;
            }
        }
        return max;
    }

    public static String toUpper(String a) {
        String x = "";
        for (int i = 0; i < a.length(); i++) {
            if (a.charAt(i) >= 97 && a.charAt(i) <= 122 && a.charAt(i) != ' ') {
                x = x + (char) (a.charAt(i) - 32);
            } else {
                x = x + a.charAt(i);
            }
        }
        return x;
    }

    public static String toLower(String a) {
        String x = "";
        for (int i = 0; i < a.length(); i++) {
            if (a.charAt(i) >= 65 && a.charAt(i) <= 90 && a.charAt(i) != ' ') {
                x = x + (char) (a.charAt(i) + 32);
            } else {
                x = x + a.charAt(i);
            }
        }
        return x;
    }

    public static String toUpperFirstChar(String a) {
        String x = "";

        String[] arr = a.split(" ");
        
        for(int i = 0;i<arr.length;i++)
        {
            for(int j = 0;j< arr[i].length();j++)
            {
                if( j == 0 && arr[i].charAt(0) >= 97 && arr[i].charAt(0) <= 122)
                {
                    x = x + (char) (arr[i].charAt(0) - 32);
                }
                else if(arr[i].charAt(j) >= 65 && arr[i].charAt(j) <= 90 && j != 0)
                {
                    x = x + (char) (arr[i].charAt(j) + 32);
                }
                else{
                    x = x + (char) (arr[i].charAt(j));
                }
            }
            if(i != (arr.length - 1) )
            {
                x = x + " ";
            }
        }       
        return x;
    }
    
    public static int Fibonacci(int n)
    {
        if(n==1 || n == 2)
        {
            return 1;
        }
        return Fibonacci(n - 1) + Fibonacci(n - 2);
    }
}
