/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8_lab2;

/**
 *
 * @author ADMIN
 */
public class SinhVienCNTT extends SinhVien{
    
    private double web;
    private double nhung;
    private double android;

    public SinhVienCNTT(double web, double nhung, double android, String hoTen, String nghanhHoc) {
        super(hoTen, nghanhHoc);
        this.web = web;
        this.nhung = nhung;
        this.android = android;
    }

    @Override
    public double getDiem() {
        return (web+android*2+nhung*2)/5;
    }
    
}
