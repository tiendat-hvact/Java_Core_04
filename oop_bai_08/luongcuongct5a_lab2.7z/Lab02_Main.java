/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8_lab2;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Lab02_Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int T = scan.nextInt();
        int j;

        for (int i = 1; i <= T; i++) {

            int M = scan.nextInt();
            int N = scan.nextInt();
            int P = scan.nextInt();

            SinhVienATTT[] arrATTT = new SinhVienATTT[M];
            SinhVienCNTT[] arrCNTT = new SinhVienCNTT[N];
            SinhVienDTVT[] arrDTVT = new SinhVienDTVT[P];

            int x = scan.nextInt();
            int y = scan.nextInt();
            int z = scan.nextInt();

            scan.nextLine();

            for (j = 0; j < M; j++) {
                String ten = scan.nextLine();
                double madoc = scan.nextDouble();
                double laptrinhAT = scan.nextDouble();
                double dieutraso = scan.nextDouble();
                scan.nextLine();

                arrATTT[j] = new SinhVienATTT(madoc, laptrinhAT, dieutraso, ten, "ATTT");
            }

            for (j = 0; j < N; j++) {
                String ten = scan.nextLine();
                double web = scan.nextDouble();
                double android = scan.nextDouble();
                double nhung = scan.nextDouble();
                scan.nextLine();

                arrCNTT[j] = new SinhVienCNTT(web, nhung, android, ten, "CNTT");
            }

            for (j = 0; j < P; j++) {
                String ten = scan.nextLine();
                double tds = scan.nextDouble();
                double module = scan.nextDouble();
                double vdk = scan.nextDouble();
                scan.nextLine();

                arrDTVT[j] = new SinhVienDTVT(tds, module, vdk, ten, "DTVT");
            }

            System.out.printf("Case #%d:\n", i);

            System.out.println(arrATTT[x].hienThiThongTin());

            System.out.println(arrCNTT[y].hienThiThongTin());

            System.out.println(arrDTVT[z].hienThiThongTin());
        }
    }
}
