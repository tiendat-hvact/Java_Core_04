/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8_lab2;

/**
 *
 * @author ADMIN
 */
public abstract class SinhVien {
    private String hoTen;
    private String nghanhHoc;

    public SinhVien(String hoTen, String nghanhHoc) {
        this.hoTen = hoTen;
        this.nghanhHoc = nghanhHoc;
    }
    
    public abstract double getDiem();

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getNghanhHoc() {
        return nghanhHoc;
    }

    public void setNghanhHoc(String nghanhHoc) {
        this.nghanhHoc = nghanhHoc;
    }
    
    public String getHocLuc(){
       
       if(getDiem() >= 0&&getDiem() < 4){
           return "Yeu";
       }else if(getDiem() < 6 && getDiem() >= 4){
           return "Trung binh";
       }else if(getDiem() < 7 && getDiem() >= 6){
           return "Trung binh kha";
       }else if(getDiem() < 8 && getDiem() >= 7){
           return "Kha";
       }else if(getDiem() < 9 && getDiem() >= 8){
           return "Gioi";
       }else if(getDiem() <= 10 && getDiem() >= 9){
           return "Xuat sac";
       } else return "";
    }
    
    public String hienThiThongTin(){
        String s = String.format("SV: %-20s – %s – %.2f – %s",getHoTen(),getNghanhHoc(), getDiem(), getHocLuc());
        return s;
    }
}
