/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai8_lab2;

/**
 *
 * @author ADMIN
 */
public class SinhVienDTVT extends SinhVien{
    
    private double truyendanso;
    private double thietkemodule;
    private double vidieukhien;

    public SinhVienDTVT(double truyendanso, double thietkemodule, double vidieukhien, String hoTen, String nghanhHoc) {
        super(hoTen, nghanhHoc);
        this.truyendanso = truyendanso;
        this.thietkemodule = thietkemodule;
        this.vidieukhien = vidieukhien;
    }     

    @Override
    public double getDiem() {
        return (vidieukhien*2+truyendanso+thietkemodule)/4;
    }

    public double getTruyendanso() {
        return truyendanso;
    }

    public void setTruyendanso(double truyendanso) {
        this.truyendanso = truyendanso;
    }

    public double getThietkemodule() {
        return thietkemodule;
    }

    public void setThietkemodule(double thietkemodule) {
        this.thietkemodule = thietkemodule;
    }

    public double getVidieukhien() {
        return vidieukhien;
    }

    public void setVidieukhien(double vidieukhien) {
        this.vidieukhien = vidieukhien;
    }
    
    
    
}
