/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson08.lab02;

/**
 *
 * @author Luc
 */
public class SinhVienCNTT extends SinhVien{
    private double Web;
    private double Android;
    private double Nhúng;

    public SinhVienCNTT() {
    }

    public SinhVienCNTT(double Web, double Android, double Nhúng) {
        this.Web = Web;
        this.Android = Android;
        this.Nhúng = Nhúng;
    }

    public SinhVienCNTT(double Web, double Android, double Nhúng, String hoTen, String nganhHoc) {
        super(hoTen, nganhHoc);
        this.Web = Web;
        this.Android = Android;
        this.Nhúng = Nhúng;
    }

    public double getWeb() {
        return Web;
    }

    public void setWeb(double Web) {
        this.Web = Web;
    }

    public double getAndroid() {
        return Android;
    }

    public void setAndroid(double Android) {
        this.Android = Android;
    }

    public double getNhúng() {
        return Nhúng;
    }

    public void setNhúng(double Nhúng) {
        this.Nhúng = Nhúng;
    }

    @Override
    public double getDiem() {
       return (getWeb()+getAndroid()*2+getNhúng()*2)/5;
    }
    
    
}
