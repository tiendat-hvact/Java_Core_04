/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson08.lab02;

/**
 *
 * @author Luc
 */
public class SinhVienDTVT extends SinhVien {

    private double truyenDanSo;
    private double thietKeMobile;
    private double viDieuKhien;

    public SinhVienDTVT() {
    }

    public SinhVienDTVT(double truyenDanSo, double thietKeMobile, double viDieuKhien) {
        this.truyenDanSo = truyenDanSo;
        this.thietKeMobile = thietKeMobile;
        this.viDieuKhien = viDieuKhien;
    }

    public SinhVienDTVT(double truyenDanSo, double thietKeMobile, double viDieuKhien, String hoTen, String nganhHoc) {
        super(hoTen, nganhHoc);
        this.truyenDanSo = truyenDanSo;
        this.thietKeMobile = thietKeMobile;
        this.viDieuKhien = viDieuKhien;
    }

    public double getTruyenDanSo() {
        return truyenDanSo;
    }

    public void setTruyenDanSo(double truyenDanSo) {
        this.truyenDanSo = truyenDanSo;
    }

    public double getThietKeMobile() {
        return thietKeMobile;
    }

    public void setThietKeMobile(double thietKeMobile) {
        this.thietKeMobile = thietKeMobile;
    }

    public double getViDieuKhien() {
        return viDieuKhien;
    }

    public void setViDieuKhien(double viDieuKhien) {
        this.viDieuKhien = viDieuKhien;
    }

    @Override
    public double getDiem() {
        return (getViDieuKhien() * 2 + getTruyenDanSo() + getThietKeMobile()) / 4;
    }

}
