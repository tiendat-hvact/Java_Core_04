/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson08.lab02;

/**
 *
 * @author Luc
 */
public class SinhVienATTT extends SinhVien{
    private double maDoc;
    private double lapTrinhAnToan;
    private double dieuTraSo;

    public SinhVienATTT() {
    }

    public SinhVienATTT(double maDoc, double lapTrinhAnToan, double dieuTraSo) {
        this.maDoc = maDoc;
        this.lapTrinhAnToan = lapTrinhAnToan;
        this.dieuTraSo = dieuTraSo;
    }

    public SinhVienATTT(double maDoc, double lapTrinhAnToan, double dieuTraSo, String hoTen, String nganhHoc) {
        super(hoTen, nganhHoc);
        this.maDoc = maDoc;
        this.lapTrinhAnToan = lapTrinhAnToan;
        this.dieuTraSo = dieuTraSo;
    }

    public double getMaDoc() {
        return maDoc;
    }

    public void setMaDoc(double maDoc) {
        this.maDoc = maDoc;
    }

    public double getLapTrinhAnToan() {
        return lapTrinhAnToan;
    }

    public void setLapTrinhAnToan(double lapTrinhAnToan) {
        this.lapTrinhAnToan = lapTrinhAnToan;
    }

    public double getDieuTraSo() {
        return dieuTraSo;
    }

    public void setDieuTraSo(double dieuTraSo) {
        this.dieuTraSo = dieuTraSo;
    }

    @Override
    public double getDiem() {
         return (getMaDoc()*2+getLapTrinhAnToan()*2+getDieuTraSo())/5;
    }

    
    
}
