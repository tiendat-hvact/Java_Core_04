/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson08.lab02;

/**
 *
 * @author Luc
 */
public abstract class SinhVien {

    private String hoTen;
    private String nganhHoc;

    public SinhVien() {
    }

    public SinhVien(String hoTen, String nganhHoc) {
        this.hoTen = hoTen;
        this.nganhHoc = nganhHoc;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getNganhHoc() {
        return nganhHoc;
    }

    public void setNganhHoc(String nganhHoc) {
        this.nganhHoc = nganhHoc;
    }

    public abstract double getDiem();

    public String getHocLuc() {
        if (getDiem() >= 0 && getDiem() < 4) {
            return "Yeu";
        } else if (getDiem() >= 4 && getDiem() < 6) {
            return "Trung binh";

        } else if (getDiem() >= 6 && getDiem() < 7) {
            return "Trung binh kha";
        } else if (getDiem() >= 7 && getDiem() < 8) {
            return "Kha";

        } else if (getDiem() >= 8 && getDiem() < 9) {
            return "Gioi";

        } else {
            return "Xuat sac";
        }
    }

    public String hienthiThongTin() {
        String s = String.format("SV: %-20s –%s –%.2f –%s", getHoTen(), getNganhHoc(), getDiem(), getHocLuc());
        return s;
    }
}
