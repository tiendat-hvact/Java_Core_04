/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson08.lab02;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int testcase = sc.nextInt();
        int m, n, p, x, y, z, i, j;
        for (i = 1; i < testcase; i++) {
            m = sc.nextInt();
            n = sc.nextInt();
            p = sc.nextInt();
            x = sc.nextInt();
            y = sc.nextInt();
            z = sc.nextInt();
            SinhVienATTT[] svat = new SinhVienATTT[m];
            for (j = 0; j < m; j++) {
                sc.nextLine();
                svat[j] = new SinhVienATTT();
                svat[j].setHoTen(sc.nextLine());
                svat[j].setNganhHoc("ATTT");
                svat[j].setMaDoc(sc.nextDouble());
                svat[j].setLapTrinhAnToan(sc.nextDouble());
                svat[j].setDieuTraSo(sc.nextDouble());

            }
            SinhVienCNTT[] svcn = new SinhVienCNTT[n];
            for (j = 0; j < n; j++) {
                sc.nextLine();
                svcn[j] = new SinhVienCNTT();
                svcn[j].setHoTen(sc.nextLine());
                svcn[j].setNganhHoc("CNTT");
                svcn[j].setWeb(sc.nextDouble());
                svcn[j].setAndroid(sc.nextDouble());
                svcn[j].setNhúng(sc.nextDouble());

            }
            SinhVienDTVT[] svvt = new SinhVienDTVT[p];
            for (j = 0; j < p; j++) {
                sc.nextLine();
                svvt[j] = new SinhVienDTVT();
                svvt[j].setHoTen(sc.nextLine());
                svvt[j].setNganhHoc("DTVT");
                svvt[j].setTruyenDanSo(sc.nextDouble());
                svvt[j].setThietKeMobile(sc.nextDouble());
                svvt[j].setViDieuKhien(sc.nextDouble());

            }
            System.out.printf("Case #%d:/n", j);
            System.out.println(svat[x].hienthiThongTin());
            System.out.println(svcn[y].hienthiThongTin());
            System.out.println(svvt[z].hienthiThongTin());

        }

    }
}
