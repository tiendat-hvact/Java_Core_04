/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson08.lab01;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class lab01_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        int i,j, M, N, q, p;
        for (i = 1; i <= T; i++) {
            M = sc.nextInt();
            N = sc.nextInt();
            p = sc.nextInt();
            q = sc.nextInt();
            HinhChuNhat[] arrHcn = new HinhChuNhat[M];
            for (j = 0; j < arrHcn.length; j++) {
                arrHcn[j] = new HinhChuNhat(sc.nextDouble(), sc.nextDouble());

            }
            HinhVuong[] arrHv = new HinhVuong[N];
            for (j = 0; j < arrHv.length; j++) {
                arrHv[j] = new HinhVuong(sc.nextDouble());
            }
            int[] arrP = new int[p];
            for ( j = 0; j < p; j++) {
                arrP[j] = sc.nextInt();
            }

            int[] arrQ = new int[q];

            for (j = 0; j < q; j++) {
                arrQ[j] = sc.nextInt();
            }

            System.out.printf("Case #%d:\n", i);

            for ( j = 0; j < p; j++) {
                System.out.println(arrHcn[arrP[j]].hienThiThongTin());
            }

            for ( j = 0; j < q; j++) {
                System.out.println(arrHv[arrQ[j]].hienThiThongTin());
            }
        }
    }
}
