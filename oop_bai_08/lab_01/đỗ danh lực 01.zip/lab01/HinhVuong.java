/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson08.lab01;

/**
 *
 * @author Luc
 */
public class HinhVuong extends HinhChuNhat{
    private double canh;

    public HinhVuong() {
    }

    public HinhVuong(double canh) {
        this.canh = canh;
    }

    public HinhVuong(double canh, double chieuDai, double chieuRong) {
        super(chieuDai, chieuRong);
        this.canh = canh;
    }

    public double getCanh() {
        return canh;
    }

    public void setCanh(double canh) {
        this.canh = canh;
    }

    @Override
    public double getChuVI() {
        return canh*4;
    }

    @Override
    public double getDienTich(){
      return this.canh*this.canh;
    }

    @Override
    public String hienThiThongTin() {
        String s = String.format("HV(canh = %f): chu vi = %.3f, dien tich = %.3f", getCanh(),getChuVI(), getDienTich() );
        return s;
    } 
}
   