/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Baii8_lab1;

/**
 *
 * @author ADMIN
 */
public class HinhChuNhat {
    private double chieudai;
    private double chieurong;

    public HinhChuNhat(double chieudai, double chieurong) {
        this.chieudai = chieudai;
        this.chieurong = chieurong;
    }

    public HinhChuNhat() {
    }

    public double getChieudai() {
        return chieudai;
    }

    public void setChieudai(double chieudai) {
        this.chieudai = chieudai;
    }

    public double getChieurong() {
        return chieurong;
    }

    public void setChieurong(double chieurong) {
        this.chieurong = chieurong;
    }
    
    public double getChuVi(){
        return 2*(chieudai + chieurong);
    }
    public double getDienTich(){
        return chieudai*chieurong;
    }
    public String hienThiThongTin(){
        String s = String.format("HCN(%f, %f): chu vi = %.3f, dien tich = %.3f", chieudai, chieurong, getChuVi(), getDienTich());
        return s;
    }
}
