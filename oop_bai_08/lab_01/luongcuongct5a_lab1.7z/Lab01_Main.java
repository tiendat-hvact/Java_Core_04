/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Baii8_lab1;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Lab01_Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int T = scan.nextInt();
        int i, j;

        for (j = 1; j <= T; j++) {
            int M = scan.nextInt();
            int N = scan.nextInt();
            int P = scan.nextInt();
            int Q = scan.nextInt();

            HinhChuNhat[] arrHCN = new HinhChuNhat[M];

            for (i = 0; i < arrHCN.length; i++) {
                double chieuDai = scan.nextDouble();
                double chieuRong = scan.nextDouble();
                arrHCN[i] = new HinhChuNhat(chieuDai, chieuRong);
            }

            HinhVuong[] arrHV = new HinhVuong[N];

            for (i = 0; i < arrHV.length; i++) {
                double canh = scan.nextDouble();
                arrHV[i] = new HinhVuong(canh);
            }

            int[] arrP = new int[P];

            for (i = 0; i < P; i++) {
                arrP[i] = scan.nextInt();
            }

            int[] arrQ = new int[Q];

            for (i = 0; i < Q; i++) {
                arrQ[i] = scan.nextInt();
            }

            // Output
            System.out.printf("Case #%d:\n", j);

            for (i = 0; i < P; i++) {
                System.out.println(arrHCN[arrP[i]].hienThiThongTin());
            }

            for (i = 0; i < Q; i++) {
                System.out.println(arrHV[arrQ[i]].hienThiThongTin());
            }
        }
    }
}
