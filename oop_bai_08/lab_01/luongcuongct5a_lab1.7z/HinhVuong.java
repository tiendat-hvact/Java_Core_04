/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Baii8_lab1;

/**
 *
 * @author ADMIN
 */
public class HinhVuong extends HinhChuNhat{
    private double canh;

    public HinhVuong() {
    }
    
    public HinhVuong(double canh){
        this.canh = canh;
    }

    public double getCanh() {
        return canh;
    }

    public void setCanh(double canh) {
        this.canh = canh;
    }
    
    @Override
    public double getChuVi(){
        return 4*canh;
    }
    
    @Override
    public double getDienTich(){
        return canh*canh;
    }
    
    @Override
    public String hienThiThongTin(){
        String s = String.format("HV(canh = %f): chu vi = %.3f, dien tich = %.3f", getCanh(), getChuVi(), getDienTich() );
        
        return s;
    }
        
}
