/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson09.lab02;

/**
 *
 * @author Luc
 */
public class FullTimeEmployee extends Employee{

    public FullTimeEmployee() {
    }

    public FullTimeEmployee(String name, int paymentPerHour) {
        super(name, paymentPerHour);
    }

    @Override
    public int calculatesalary() {
      return 8*getPaymentPerHour();
    }

    @Override
    public void showInfo() {
        System.out.println("Full time employee:");
        System.out.printf("Name: %s, salary per day: %d\n",getName(),calculatesalary());
    }
    
}
