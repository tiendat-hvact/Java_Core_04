/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson09.lab02;

/**
 *
 * @author Luc
 */
public class PartTimeEmployee extends Employee{
    private int workingHours;

    public PartTimeEmployee() {
    }

    public PartTimeEmployee(int workingHours) {
        this.workingHours = workingHours;
    }

    public PartTimeEmployee(int workingHours, String name, int paymentPerHour) {
        super(name, paymentPerHour);
        this.workingHours = workingHours;
    }

    public int getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(int workingHours) {
        this.workingHours = workingHours;
    }


    @Override
    public int calculatesalary() {
       return getWorkingHours()*getPaymentPerHour();
    }

    @Override
    public void showInfo() {
        System.out.println("Part time employee:");
        System.out.printf("Name: %s, salary per day: %d\n",getName(),calculatesalary());
      
    }
    
    
}
