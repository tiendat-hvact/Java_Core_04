/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson09.lab02;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class Lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int M, N, P, Q;
        int T = sc.nextInt();
        for (int i = 0; i < T; i++) {
            M = sc.nextInt();
            N = sc.nextInt();
            P = sc.nextInt();
            Q = sc.nextInt();
            FullTimeEmployee[] a = new FullTimeEmployee[M];
            PartTimeEmployee[] b = new PartTimeEmployee[N];
            for (int j = 0; j < M; j++) {
                a[j] = new FullTimeEmployee();
                sc.nextLine();
                a[j].setName(sc.nextLine());
                a[j].setPaymentPerHour(sc.nextInt());
            }
            for (int j = 0; j < N; j++) {
                sc.nextLine();
                b[j] = new PartTimeEmployee();
                b[j].setName(sc.nextLine());
                b[j].setPaymentPerHour(sc.nextInt());
                b[j].setWorkingHours(sc.nextInt());
            }
            int[] full = new int[P];
            int[] part = new int[Q];
            for (int j = 0; j < P; j++) {
                full[j] = sc.nextInt();
            }
            for (int j = 0; j < Q; j++) {
                part[j] = sc.nextInt();
            }
            System.out.printf("Case #%d\n", i + 1);
            for (int j = 0; j < P; j++) {
                a[full[j]].showInfo();
            }
            for (int j = 0; j < Q; j++) {
                b[part[j]].showInfo();
            }
        }

    }
}
