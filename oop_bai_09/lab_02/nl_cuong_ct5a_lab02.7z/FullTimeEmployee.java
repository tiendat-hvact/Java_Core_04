/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lesson09.lab02;

/**
 *
 * @author ADMIN
 */
public class FullTimeEmployee  extends Employee{

    public FullTimeEmployee(String name, int paymentPerHour) {
        super(name, paymentPerHour);
    }
    
    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public int calculateSalary() {
        return super.getPaymentPerHour()*8;
    }

    @Override
    public void showInfo() {
        System.out.println("Full time employee:");
        System.out.printf("Name: %s, salary per day: %d\n", getName(), calculateSalary());
    }
}
