/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lesson09.lab02;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Lab02_Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int T = scan.nextInt();
        int k,i;
        for(k = 1;k<=T;k++){
            int M = scan.nextInt();
            int N = scan.nextInt();
            
            FullTimeEmployee[] arrFull = new FullTimeEmployee[M];
            PartTimeEmployee[] arrPart = new PartTimeEmployee[N];
            
            int P = scan.nextInt();
            int Q = scan.nextInt();
            scan.nextLine();
            
            for(i = 0;i<M;i++){
                String name = scan.nextLine();
                int paymentPerHour = scan.nextInt();
                scan.nextLine();
                arrFull[i] = new FullTimeEmployee(name, paymentPerHour);
            }
            
            for(i = 0;i<N;i++){
                String name = scan.nextLine();
                int paymentPerHour = scan.nextInt();
                int workingHours = scan.nextInt();
                scan.nextLine();
                arrPart[i] = new PartTimeEmployee(name, paymentPerHour, workingHours);
            }
            
            int[] arrP = new int[P];
            int[] arrQ = new int[Q];
            
            for(i = 0;i<P;i++){
                arrP[i] = scan.nextInt();
            }
            for(i = 0;i<Q;i++){
                arrQ[i] = scan.nextInt();
            }
            //output
            
            System.out.printf("Case #%d:\n",k);
            for(i = 0;i<P;i++){
                arrFull[arrP[i]].showInfo();
            }
            for(i = 0;i<Q;i++){
                arrPart[arrQ[i]].showInfo();
            }
            
            
        }
    }
}
