/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lesson09.lab02;

/**
 *
 * @author ADMIN
 */
public class PartTimeEmployee extends Employee{
    private int workingHours;

    public PartTimeEmployee(String name, int paymentPerHour, int workingHours) {
        super(name, paymentPerHour);
        this.workingHours = workingHours;
    }
    
    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public int calculateSalary() {
        return super.getPaymentPerHour()*workingHours;
    }

    @Override
    public void showInfo() {
        System.out.println("Part time employee:");
        System.out.printf("Name: %s, salary per day: %d\n", getName(), calculateSalary());
    }
}
