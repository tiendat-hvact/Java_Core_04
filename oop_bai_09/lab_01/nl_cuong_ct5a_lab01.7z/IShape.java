/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lesson09.lab01;

/**
 *
 * @author ADMIN
 */
public interface IShape {
    public abstract double getPerimeter();
    public abstract double getArea();
    public abstract void show();
}
