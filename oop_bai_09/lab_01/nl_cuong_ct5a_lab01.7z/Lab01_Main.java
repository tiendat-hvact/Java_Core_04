/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lesson09.lab01;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Lab01_Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int T = scan.nextInt();
        int k,i;
        for(k = 1;k <= T;k++){
            int M = scan.nextInt();
            int N = scan.nextInt();
            int P = scan.nextInt();
            int Q = scan.nextInt();
            
            Rectangle[] arrRTL = new Rectangle[M];
            Circle[] arrCircle = new Circle[N];
            
            for(i = 0;i<M;i++){
                double height = scan.nextDouble();
                double width = scan.nextDouble();
                arrRTL[i] = new Rectangle(height, width);
            }
            
            for(i = 0;i<N;i++){
                double radius = scan.nextDouble();
                arrCircle[i] = new Circle(radius);
            }
            
            int[] arrP = new int[P];
            int[] arrQ = new int[Q];
            
            for(i = 0;i<P;i++){
                arrP[i] = scan.nextInt();
            }
            for(i = 0;i<Q;i++){
                arrQ[i] = scan.nextInt();
            }
            
            //output
            System.out.printf("Case #%d:\n",k);
            for(i = 0;i<P;i++){
                arrRTL[arrP[i]].show();
            }
            for(i = 0;i<Q;i++){
                arrCircle[arrQ[i]].show();
            }
        }
        
    }
}
