/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson09.lab01;

/**
 *
 * @author Luc
 */
public class Circle implements IShape{
    private double radius;

    public Circle() {
    }

    public Circle(double radius) {
        this.radius = radius;
    }
    
    @Override
    public double getPerimeter() {
       return 2*Math.PI*getRadius();
    }

    @Override
    public double getArea() {
       return getRadius()*getRadius()*Math.PI;
    }

    @Override
    public void show() {
        String t=String.format("Circle(r = %f): perimeter = %.3f, area = %.3f",getRadius(),getPerimeter(),getArea());
        System.out.println(t);
        
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }
    
}
