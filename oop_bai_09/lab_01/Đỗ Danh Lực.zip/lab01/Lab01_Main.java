/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson09.lab01;

import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class Lab01_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int M, N, P, Q, T, i, j;
        T = sc.nextInt();
        for (i = 0; i < T; i++) {
            M = sc.nextInt();
            N = sc.nextInt();
            P = sc.nextInt();
            Q = sc.nextInt();
            Rectangle[] arrHcn = new Rectangle[M];
            for (j = 0; j < arrHcn.length; j++) {
                arrHcn[j] = new Rectangle(sc.nextDouble(), sc.nextDouble());
            }
            Circle[] arrHv = new Circle[N];
            for (j = 0; j < arrHv.length; j++) {
                arrHv[j] = new Circle(sc.nextDouble());

            }

            int[] ttcn = new int[P];
            for (j = 0; j < P; j++) {
                ttcn[j] = sc.nextInt();

            }
            int[] tthv = new int[Q];
            for (j = 0; j < Q; j++) {
                tthv[j] = sc.nextInt();

            }
            System.out.printf("Case #d:\n", i+1);
            for (j = 0; j < P; j++) {
              arrHcn[ttcn[j]].show();

            }
            for (j = 0; j < Q; j++) {
              arrHv[tthv[j]].show();
 
            }
            

        }
        
    }
}
