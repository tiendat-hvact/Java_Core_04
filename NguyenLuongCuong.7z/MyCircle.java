/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7;

/**
 *
 * @author ADMIN
 */
public class MyCircle {
    private MyPoint centerCircl;
    private double radius;

    public MyCircle() {
        MyPoint p = new MyPoint(0,0);
        this.centerCircl = p;
        this.radius = 0;
    }

    public MyCircle(double x, double y, double radius) {
        this.centerCircl = new MyPoint();
        this.centerCircl.setX(x);
        this.centerCircl.setY(y);
        this.radius = radius;
    }

    public MyCircle(MyPoint centerCircl, double radius) {
        this.centerCircl = centerCircl;
        this.radius = radius;
    }

    
    
    public MyPoint getCenterCircl() {
        return centerCircl;
    }

    public void setCenterCircl(MyPoint centerCircl) {
        this.centerCircl = centerCircl;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }
    
    public double getCircumference()
    {
        return Math.PI*2*this.radius;
    }
    
    public double getArea()
    {
        return Math.pow(radius, 2)*Math.PI;
    }

    @Override
    public String toString() {
        return "Circle info: (" + this.centerCircl.getX() + "," + this.centerCircl.getY()
                + "), radius=" + this.radius +", circumference= " + getCircumference() + ",area = " + getArea();
    }
    
    
}
