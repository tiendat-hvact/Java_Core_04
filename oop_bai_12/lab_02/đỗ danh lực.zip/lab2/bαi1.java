/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson12.lab2;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class bài1 {

    static Scanner scanner = new Scanner(System.in);

    static LocalDate localDate() {
        int day = scanner.nextInt();
        int month = scanner.nextInt();
        int year = scanner.nextInt();
        LocalDate a = LocalDate.of(year, month, day);
        return a;
    }

    public static void main(String[] args) {
        int T = scanner.nextInt();
        for (int i = 1; i <= T; i++) {
            LocalDate a = localDate();
            String dateString = a.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            LocalDate b = localDate();
            String dateString2 = b.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            Period period = Period.between(a, b);
            System.out.printf("Case #%d:\n", i);
            System.out.printf("Difference between %s and %s:\n%d Year(s), %d Month(s), %d Day(s)\n", dateString, dateString2, Math.abs(period.getYears()),
                    Math.abs(period.getMonths()), Math.abs(period.getDays()));
        }
    }

}
