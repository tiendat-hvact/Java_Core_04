/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson12.lab2;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class bai2 {

    static Scanner scanner = new Scanner(System.in);

    static LocalDateTime localDateTime() {
        int day = scanner.nextInt();
        int month = scanner.nextInt();
        int year = scanner.nextInt();
        int hour = scanner.nextInt();
        int minute = scanner.nextInt();
        int second = scanner.nextInt();
        LocalDateTime a = LocalDateTime.of(year, month, day, hour, minute, second);
        return a;
    }

    public static void main(String[] args) {
        int T = scanner.nextInt();
        for (int i = 1; i <= T; i++) {
            LocalDateTime a = localDateTime();
            LocalDateTime b = localDateTime();
            Duration duration = Duration.between(a, b);
            String dateString = a.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
            String dateString2 = b.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
            int hour = (int) (duration.toHours() - duration.toDays() * 24);
            int minute = (int) (duration.toMinutes() - duration.toHours() * 60);
            int second = (int) (duration.toSeconds() - duration.toMinutes() * 60);
            System.out.printf("Case #%d:\n", i);
            System.out.printf("Difference between (%s) and (%s):\n%d Days, %d Hours, %d Minutes, %d Seconds\n ", dateString, dateString2, Math.abs(duration.toDays()), hour, minute, second);
        }
    }

}
