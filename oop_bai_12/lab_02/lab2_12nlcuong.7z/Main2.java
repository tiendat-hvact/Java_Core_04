/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_12;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int T = scan.nextInt();
        for(int i = 1;i<=T;i++){
            int ngay1 = scan.nextInt();
            int thang1 = scan.nextInt();
            int nam1 = scan.nextInt();
            int gio1 = scan.nextInt();
            int phut1 = scan.nextInt();
            int giay1 = scan.nextInt();
            
            int ngay2 = scan.nextInt();
            int thang2 = scan.nextInt();
            int nam2 = scan.nextInt();
            int gio2 = scan.nextInt();
            int phut2 = scan.nextInt();
            int giay2 = scan.nextInt();
            
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
            LocalDateTime localdt1 = LocalDateTime.of(nam1, thang1, ngay1,gio1,phut1,giay1);
            LocalDateTime localdt2 = LocalDateTime.of(nam2, thang2, ngay2,gio2,phut2,giay2);
            
            int giayValue = 0;
            int gioValue = 0;
            int phutValue = 0;
            int ngayValue = 0;
            
            if(localdt1.isBefore(localdt2)){
                
                while (localdt1.isBefore(localdt2)) {                    
                    localdt1 = localdt1.plusDays(1);
                    ngayValue++;
                }
                if(!localdt1.equals(localdt2)){
                    localdt1 = localdt1.minusDays(1);
                    ngayValue--;
                }
                
                while (localdt1.isBefore(localdt2)) {                    
                    localdt1 = localdt1.plusHours(1);
                    gioValue++;
                }
                if(!localdt1.equals(localdt2)){
                    localdt1 = localdt1.minusHours(1);
                    gioValue--;
                }
                
                
                while (localdt1.isBefore(localdt2)) {                    
                    localdt1 = localdt1.plusMinutes(1);
                    phutValue++;
                }
                if(!localdt2.equals(localdt1)){
                    localdt1 = localdt1.minusMinutes(1);
                    phutValue--;
                }
                
                while (localdt1.isBefore(localdt2)) {                    
                    localdt1 = localdt1.plusSeconds(1);
                    giayValue++;
                }
            }else{
                while (localdt2.isBefore(localdt1)) {                    
                    localdt2 = localdt2.plusDays(1);
                    ngayValue++;
                }
                if(!localdt2.equals(localdt1)){
                    localdt2 = localdt2.minusDays(1);
                    ngayValue--;
                }
                
                while (localdt2.isBefore(localdt1)) {                    
                    localdt2 = localdt2.plusHours(1);
                    gioValue++;
                }
                if(!localdt2.equals(localdt1)){
                    localdt2 = localdt2.minusHours(1);
                    gioValue--;
                }
                
                while (localdt2.isBefore(localdt1)) {                    
                    localdt2 = localdt2.plusMinutes(1);
                    phutValue++;
                }
                if(!localdt1.equals(localdt2)){
                    localdt2 = localdt2.minusMinutes(1);
                    phutValue--;
                }
                
                while (localdt2.isBefore(localdt1)) {                    
                    localdt2 = localdt2.plusSeconds(1);
                    giayValue++;
                }
            }
            
            System.out.printf("Case#%d:\n",i);
            System.out.println("Difference between ("+localdt1.format(dateTimeFormatter)+") and ("+localdt2.format(dateTimeFormatter)+"):");
            System.out.printf("%d Days, %d Hours, %d Minutes, %d Seconds",ngayValue,gioValue,phutValue,giayValue);
        }
    }
}
