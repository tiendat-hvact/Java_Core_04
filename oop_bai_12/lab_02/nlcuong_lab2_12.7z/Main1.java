/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_12;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main1 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int T = scan.nextInt();
        for(int i = 1;i<=T;i++){
            int ngay1 = scan.nextInt();
            int thang1 = scan.nextInt();
            int nam1 = scan.nextInt();
            int ngay2 = scan.nextInt();
            int thang2 = scan.nextInt();
            int nam2 = scan.nextInt();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate local1 = LocalDate.of(nam1, thang1, ngay1);
            LocalDate local2 = LocalDate.of(nam2, thang2, ngay2);
            LocalDate local3 = LocalDate.of(nam1, thang1, ngay1);
            LocalDate local4 = LocalDate.of(nam2, thang2, ngay2);
            
            int ngayValue = 0;
            int thangValue = 0;
            int namValue = 0;
            
            if(local1.isBefore(local2)){
                while (local1.isBefore(local2)) {                    
                    local1 = local1.plusYears(1);
                    namValue++;
                }
                if(!local1.equals(local2)){
                    local1 = local1.minusYears(1);
                    namValue--;
                }
                
                
                while (local1.isBefore(local2)) {                    
                    local1 = local1.plusMonths(1);
                    thangValue++;
                }
                if(!local2.equals(local1)){
                    local1 = local1.minusMonths(1);
                    thangValue--;
                    if(local1.getDayOfMonth() < ngay2){
                        local1 = local1.of(nam2, thang2, ngay1);
                    }else{
                        local1 = local1.of(nam2, thang2, ngay1);
                        local1 = local1.minusMonths(1);
                    } 
                }
                
                while (local1.isBefore(local2)) {                    
                    local1 = local1.plusDays(1);
                    ngayValue++;
                }
            }else{
                while (local2.isBefore(local1)) {                    
                    local2 = local2.plusYears(1);
                    namValue++;
                }
                if(!local2.equals(local1)){
                    local2 = local2.minusYears(1);
                    namValue--;
                }
                
                while (local2.isBefore(local1)) {                    
                    local2 = local2.plusMonths(1);
                    thangValue++;
                }
                if(!local2.equals(local1)){
                    local2 = local2.minusMonths(1);
                    thangValue--;
                    if(local2.getDayOfMonth() < ngay1){
                        local2 = local2.of(nam1, thang1, ngay2);
                    }else{
                        local2= local2.of(nam1, thang1, ngay2);
                        local2= local2.minusMonths(1);
                    }
                }
                while (local2.isBefore(local1)) {                    
                    local2 = local2.plusDays(1);
                    ngayValue++;
                } 
            }
            System.out.printf("Case#%d:\n",i);
            System.out.print("Difference between "+local3.format(dateTimeFormatter)+" and "+local4.format(dateTimeFormatter)+":");
            System.out.printf("%d Year(s), %d Month(s), %d Day(s)",namValue,thangValue,ngayValue);
        }
    }
}
