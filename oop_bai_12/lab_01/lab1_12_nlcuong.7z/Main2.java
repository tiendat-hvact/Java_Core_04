/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1_12;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int T = scan.nextInt();
        for(int i = 1;i<=T;i++){
            int ngay = scan.nextInt();
            int thang = scan.nextInt();
            int nam = scan.nextInt();
            SimpleDateFormat sim = new SimpleDateFormat("EEE dd-MM-yyyy");
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("ccc dd-MM-yyyy");
            Calendar calen = Calendar.getInstance();
            calen.set(nam, thang - 1 , ngay);
            Date date = calen.getTime();
            LocalDate local1 = LocalDate.of(nam, thang, ngay);
            LocalDate local2 = LocalDate.of(nam, thang, ngay);
            while(local1.getDayOfWeek().getValue() != 1){
                local1 = local1.minusDays(1);
                System.out.println(local1.getDayOfWeek().getValue());
            }
            while(local2.getDayOfWeek().getValue() != 7){
                local2 = local2.plusDays(1);
            }
            System.out.printf("Case#%d:\n",i);
            System.out.println(sim.format(date));
            System.out.println(local1.format(dateTimeFormatter));
            System.out.println(local2.format(dateTimeFormatter));
        }
    }
}
