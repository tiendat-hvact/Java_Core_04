/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1_12;

import java.util.Calendar;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int T = scan.nextInt();        
        for(int i = 1;i<=T;i++){            
            int ngay = scan.nextInt();
            int thang = scan.nextInt() - 1;
            int nam = scan.nextInt();
            Calendar calen = Calendar.getInstance();
            calen.set(nam, thang, ngay,00,00,00);
            System.out.printf("Case#%d:\n",i);
            System.out.println(calen.getTime());
        }
    }
}
