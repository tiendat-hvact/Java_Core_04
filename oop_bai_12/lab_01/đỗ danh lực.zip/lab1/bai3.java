/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson12.lab1;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class bai3 {
      static void show(Date date) {
        DateFormat df = new SimpleDateFormat("EEE dd-MM-yyyy");
        String str = df.format(date);
        System.out.println(str);

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        int d, m, y;

        for (int i = 1; i <= T; i++) {
            Calendar c = Calendar.getInstance();
            c.clear();
            d = sc.nextInt();
            m = sc.nextInt();
            y = sc.nextInt();
            c.set(y, m - 1, d);
            Date d1 = c.getTime();

            c.set(Calendar.DAY_OF_YEAR, c.get(Calendar.DAY_OF_YEAR) - 1);
            Date d2 = c.getTime();

            c.set(Calendar.DAY_OF_YEAR, c.get(Calendar.DAY_OF_YEAR) + 2);
            Date d3 = c.getTime();

            c.set(Calendar.DAY_OF_YEAR, c.get(Calendar.DAY_OF_YEAR) - 1);
            c.getTime();
            c.set(Calendar.DAY_OF_MONTH, 1);
            Date d4 = c.getTime();

            c.set(Calendar.MONTH, c.get(Calendar.MONTH) + 1);
            c.set(Calendar.DAY_OF_YEAR, c.get(Calendar.DAY_OF_YEAR) - 1);
            Date d5 = c.getTime();
            System.out.printf("Case #%d:\n", i);
            show(d1);
            show(d2);
            show(d3);
            show(d4);
            show(d5);
        }
    }
}


