/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson12.lab1;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class bai2ss12 {

    static void show(Date date) {
        DateFormat df = new SimpleDateFormat("EEE dd-MM-yyyy");
        String dt = df.format(date);
        System.out.println(dt);

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int tc = sc.nextInt();
        int i;
        for (i = 1; i < tc; i++) {
            Calendar c = Calendar.getInstance();
            c.set(Calendar.DAY_OF_MONTH, sc.nextInt());
            c.set(Calendar.MONTH, sc.nextInt()-1);
            c.set(Calendar.YEAR, sc.nextInt());
            
            Date date1 = c.getTime();
            c.setFirstDayOfWeek(Calendar.MONDAY);
            c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
            Date date2 = c.getTime();
            c.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
            Date date3 = c.getTime();
            System.out.println("Case #" + i);
            show(date1);
            show(date2);
            show(date3);

        }

    }

}
