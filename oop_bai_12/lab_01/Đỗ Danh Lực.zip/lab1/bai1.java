/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacore.Basic.lesson12.lab1;

import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Luc
 */
public class bai1 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        int i;
        for (i = 1; i <= T; i++) {
            Calendar calendar = Calendar.getInstance();
            calendar.clear();
            calendar.set(Calendar.DAY_OF_MONTH, sc.nextInt());
            calendar.set(Calendar.MONTH, (sc.nextInt() - 1));
            calendar.set(Calendar.YEAR, sc.nextInt());
            Date date = calendar.getTime();
            System.out.printf("Case #%d:\n", i);
            System.out.println(date);

        }
    }
}



